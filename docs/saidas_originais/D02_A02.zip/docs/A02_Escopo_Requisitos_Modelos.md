# A02 — Escopo, requisitos, regras e modelos de Cyra

**Preparação documental:** 22/10/2026. **Versão:** D02/P02, saída original da IA. **Situação:** proposta para curadoria; A02 ainda não aprovada. A janela planejada de 15–18/10 não é a data de execução deste documento.

O documento consolida a conferência da fonte e dos modelos existentes e propõe contratos para A05–A09. Não implementa mecânicas, modifica o jogo ou declara testes futuros executados. Somente A01/T00 possuem validação humana registrada. Não foi encontrado outro documento consolidado equivalente à A02; os materiais anteriores são referenciados e preservados.

## 1. Fontes, precedência e estado confirmado

### 1.1 Fontes consultadas

As páginas de S01 são as posições físicas do PDF de nove páginas, contadas a partir de 1; não correspondem ao rodapé `tempfile_51932.docx`.

| Ref. | Fonte | Uso nesta conferência |
|---|---|---|
| S01 | [Relatório parcial/final assinado indicado pelo grupo](<C:/Users/caio/Downloads/(CLV) LES - 5 - Relatorio_Parcial_Final_ADS_assinado (1).pdf>) | Fonte primária: regras p. 1–3; RF p. 3–4; RNF p. 4; casos de uso e dados p. 5; persistência e metodologia anterior p. 6. Acessível; texto extraído e páginas 2–6 conferidas visualmente. Não foi substituído pelo PDF homônimo do repositório. |
| S02 | [AGENTS.md](../AGENTS.md) e pedido P02 | Limites atuais do grupo: três seções, dois tipos copiáveis/duas habilidades, dois bloqueios, um save local, física nativa, assets/narrativa humanos; somente documentação nesta tarefa. |
| S03 | [Cronograma atualizado em 15/10](Cronograma_Cyra_15-10_a_23-11-2026.md) | Decisão registrada de retirar comparação manual independente; planejamento e divisão de responsabilidades, sem comprovar execução. |
| S04 | [Guia de atividades](Guia_atividades_Cyra_2026.md), A02 e atividades relacionadas | Sugestões de percurso, habilidades, testes, reinício e avaliação; exemplos não são aprovações humanas de mecânicas. |
| S05 | [Diário](Diario_Experimento_Cyra.md), [prompts](Prompts_Utilizados.md), [README](../README.md) e histórico Git local | Estado real da A01 e rastreabilidade anterior. |
| S06 | [Untitled Diagram.png](<arquivos_tcc/Untitled Diagram.png>) e diagrama de S01 p. 5 | Casos UC01–UC05, inclusão de alteração de estado/aparência e extensão de superação de obstáculo. |
| S07 | [Untitled.sql](arquivos_tcc/Untitled.sql), [Untitled.png](arquivos_tcc/Untitled.png), [Untitled.svg](arquivos_tcc/Untitled.svg) e [svgviewer-png-output.png](arquivos_tcc/svgviewer-png-output.png) | Quatro entidades, atributos e relações do modelo de dados. SQL lido, PNGs conferidos visualmente e rótulos do SVG conferidos. |
| S08 | [Resumo de 13/10](arquivos_tcc/Resumo_e_plano_minimo_Cyra.md) e `docs/arquivos_tcc/Título.docx` | Antecedentes auxiliares: demo, plataforma, restrição geográfica. O resumo mantém a comparação manual antiga e não prevalece sobre S02/S03. Não fornece aprovação das habilidades. |

Identificação da cópia primária consultada: `C:\Users\caio\Downloads\(CLV) LES - 5 - Relatorio_Parcial_Final_ADS_assinado (1).pdf`; SHA-256 `EB0AC1E6A4F980349A6D8395438A5CF16DA054C723DFDA63E080B0F67FF647BB`. Os hashes das fontes locais relevantes acompanham a preservação D02. S01 fica fora do repositório; os colaboradores precisam ter acesso à mesma cópia para repetir a conferência. Não foi necessário recorrer a fontes web ou substituir o documento.

**Como ler as decisões:** **Registrada** = decisão explícita em S02/S03 ou estado comprovado em S05; **Proposta IA** = recomendação deste documento, ainda sem aprovação; **Pendente humana** = parâmetro ou escolha não fechado pela equipe. Redação de S01, sugestão do guia e decisão do grupo são categorias distintas.

### 1.2 Base A01 preservada

- Saída original A01: commit `9cdfcc4` e arquivo `docs/saidas_originais/D01_A01.zip`.
- Versão integrada indicada no diário: `6bf3e2d`; registros de curadoria de Caio em `ae766a2`/`008f900`.
- Reprodução, T00 e revisão por Lucas: `46d5986`, de 21/10/2026; consolidação documental: `f8a2f06`, de 22/10/2026, HEAD consultado para esta preparação.
- D01/T00 e suas capturas registram a validação de entrada, colisão, sinais e exportação Windows. O log inicial de templates ausentes é histórico, não pendência atual.
- Ambiente registrado: Godot .NET 4.7.2, SDK .NET 8.0.422, Windows Desktop x86_64. A cena de teste A01 não demonstra implementação final de RF01–RF06 nem aprovação global dos RNF.

### 1.3 Divergências e lacunas identificadas

| Tema | Fonte/modelo | Encaminhamento e status |
|---|---|---|
| Comparação manual | S01 p. 6 e S08 mencionam contrastar IA e programação manual. | **Registrada:** S03 e P02 retiram a versão manual independente. Avaliar o processo assistido e a curadoria; registrar a mudança no texto final e confirmar comunicação à orientação. Não afirmar superioridade ou economia frente a código inexistente. |
| Quantidades e plataforma | S01 p. 2 limita a até três seções; RF06 p. 4 especifica três. Não fixa dois tipos, duas habilidades ou dois bloqueios; RNF06 fala em Desktop. | **Registrada:** S02/P02 fecham exatamente três seções, dois tipos/duas habilidades, dois bloqueios e Windows x86_64. São escolhas do recorte, não transcrições da fonte. |
| Habilidades | RF04 p. 3 cita pulo duplo, ataque de fogo e investida como exemplos; S04 sugere pulo duplo/investida. | Não há escolha humana explícita localizada em S05/histórico consultado. **Proposta IA:** pulo duplo e investida, sem ataque de fogo ou terceira habilidade. |
| Limites de uso | SQL: `HABILIDADE.qt_uso` e `SAVE_JOGADOR.qt_uso_atual`; sem valores, recarga ou semântica. | **Proposta IA:** não consumir cargas permanentes; limites por salto/ação, restaurados ao pousar. A retirada dos contadores do save depende de curadoria; não atribuir essa decisão à equipe. |
| Save incompleto | S01 p. 5–6 exige derrotas, posição e inventário. Diagrama/SQL têm seção e habilidade ativa, mas não ponto seguro, coleção de aquisições nem inimigos. | **Proposta IA:** completar o estado de progresso descrito na seção 6; manter catálogos estáticos fora do save. Sem banco de dados. |
| Dados misturados | `HABILIDADE.is_desbloqueada` junta definição e progresso; `OBSTACULO_ESTADO` junta requisito estático e superação. | **Proposta IA:** separar catálogo e conjuntos persistidos, preservando a intenção das relações. |
| Casos de uso | UC01–UC05 não detalham troca de forma, morte ou retomada. A seta `extend` entre UC04 e superação é ambígua entre a figura solta e a do PDF. | Preservar originais; descrever a condição de superação textualmente e propor ações auxiliares, sem atribuir novos IDs à fonte nem corrigir UML silenciosamente. |
| Desempenho | RNF04 não fixa FPS mínimo, tolerância, duração ou equipamento. | **Pendente humana:** critérios quantitativos e protocolo na A03; medir na A10. Não inventar meta de 60 FPS ou alegar prova absoluta de ausência de vazamentos. |
| Links e histórico | S03/S04 ainda contêm links para `C:/Users/caio/Desktop/cyra/`; S05 conserva trechos do estado original da A01 e uma referência antiga a commit pendente. | Este documento usa os arquivos efetivamente encontrados em `C:/Users/caio/GIT/cyra`. Preservar o histórico A01; suas aprovações posteriores prevalecem sobre o relato original. Não executar correções alheias à A02. |

## 2. Requisitos: transcrição e interpretação separadas

### 2.1 Redação original de S01

Transcrição conferida visualmente: preservados IDs, títulos, exemplos e significado; apenas quebras de linha e espaçamento foram normalizados. Os acentos corrompidos pela extração automática foram conferidos na página renderizada.

**RF01 - Movimentação Básica — S01, p. 3, §1.2.1**

> O sistema deve permitir que o jogador controle a movimentação bidimensional da personagem Cyra (andar, pular, cair) respeitando as leis da física (gravidade e colisão) programadas na engine.

**RF02 - Sistema de Combate — S01, p. 3, §1.2.1**

> O jogo deve possuir um sistema de dano onde a protagonista pode atacar inimigos e também receber dano, com atualização em tempo real de uma barra ou contador de vida.

**RF03 - Mecânica de Absorção (Mimetismo) — S01, p. 3, §1.2.1**

> O sistema deve permitir que, ao aplicar um golpe finalizador ou comando específico em um inimigo derrotado, a personagem Cyra copie a habilidade atrelada àquele inimigo.

**RF04 - Alteração de Estado do Jogador — S01, p. 3, §1.2.1**

> Ao absorver uma habilidade, o sistema deve atualizar os parâmetros da protagonista, trocando seus sprites de animação e liberando novos inputs de ação (ex: pulo duplo, ataque de fogo, investida).

**RF05 - Sistema de Bloqueio e Liberação (Fechaduras) — S01, p. 3, §1.2.1**

> O ambiente deve conter obstáculos interativos que validem o estado atual da Cyra. O sistema só deve permitir a destruição ou transposição do obstáculo se a personagem estiver equipada com a habilidade (chave) correspondente.

**RF06 - Transição de Seções — S01, p. 4, §1.2.1 (continuação)**

> O jogo deve gerenciar a transição do jogador entre as 3 seções distintas do mapa, salvando o estado das habilidades adquiridas durante a transição.

**RNF01 - Geração de Código Híbrida (Restrição de IA) — S01, p. 4, §1.2.2**

> A estruturação lógica e os scripts (em C#) para mecânicas, física e sistemas de retaguarda devem ser gerados massivamente via inteligência artificial generativa, passando obrigatoriamente por curadoria humana antes da integração.

**RNF02 - Integridade Artística (Proibição de IA) — S01, p. 4, §1.2.2**

> Como resposta direta aos dados da pesquisa de campo, é estritamente proibido o uso de algoritmos para a geração de arquivos de áudio, trilhas sonoras, pixel art, cenários ou animações. Todos os assets criativos devem ser de autoria humana.

**RNF03 - Transparência Obrigatória — S01, p. 4, §1.2.2**

> A interface do jogo (UI/Menus) ou os créditos devem conter um aviso explícito detalhando quais módulos lógicos do sistema foram construídos com o auxílio de inteligência artificial.

**RNF04 - Estabilidade e Desempenho — S01, p. 4, §1.2.2**

> O código gerado pela IA deve provar sua viabilidade técnica mantendo uma taxa de quadros (FPS) estável e sem vazamentos de memória (memory leaks) que comprometam a execução da demo.

**RNF05 - Ambiente de Desenvolvimento — S01, p. 4, §1.2.2**

> O projeto deve ser estruturado e compilado utilizando a engine Godot.

**RNF06 - Plataforma Alvo — S01, p. 4, §1.2.2**

> O sistema deve ser empacotado como um executável voltado exclusivamente para sistemas operacionais Desktop.

### 2.2 Matriz prática de aceitação da demo — proposta IA

Todos os critérios abaixo são **previstos**, sujeitos à revisão em T01. Não são resultados. Os códigos `C-RFxx`, `C-RNFxx` e `C-SAVE` identificam cenários deste documento, não novos testes globais T02–T10; os IDs de execução serão vinculados nos registros das atividades correspondentes. T01 é a conferência documental da A02.

| Req. / origem | Demonstração objetiva proposta | Atividade correspondente | Cenário/evidência prevista | Estado atual |
|---|---|---|---|---|
| RF01 / S01 p. 3 | Percorrer piso e parede, andar nos dois sentidos, pular e cair; sem atravessar colisões nem ficar preso no percurso aprovado. | A05; integração A07; validação A10 | C-RF01: percurso e colisões; captura/vídeo `RF01_movimento`, versão e resultado esperado/observado. | Mecânica final pendente; T00 apenas valida o ator A01. |
| RF02 / S01 p. 3 | Ataque reduz vida do inimigo; dano reduz vida real da protagonista; indicador acompanha cada mudança; zero causa derrota/morte conforme regras. | A05; UI final A09; A10 | C-RF02: antes/depois de dano, derrota e reinício; evidência `RF02_vida_combate`. | Pendente implementação/teste. |
| RF03 / S01 p. 3 | Absorver cada um dos dois tipos somente após derrota; tentar antes da derrota e repetir aquisição sem duplicar progresso. | A06; A10 | C-RF03: vivo/derrotado/já absorvido; evidência `RF03_absorcao_A_B`. | Pendente implementação/teste. |
| RF04 / S01 p. 3 | Ao adquirir/equipar A ou B, ação disponível e sprites humanos correspondem à habilidade ativa; alternar preserva a outra aquisição. | A04 (recursos humanos), A06; A09/A10 | C-RF04: A, B e forma base, inclusive após morte/carga; `RF04_estado_aparencia`. | Pendente implementação/teste. |
| RF05 / S01 p. 3 | Testar cada bloqueio fechado com habilidade ausente, adquirida mas não ativa/errada e ativa correta; somente a ação correta supera pela primeira vez. | A07; A10 | C-RF05: matriz de dois bloqueios × três condições, persistência e retorno; `RF05_bloqueios`. | Pendente implementação/teste. |
| RF06 / S01 p. 4 | Fazer S1→S2→S3 e retornar S3→S2→S1, mantendo aquisições, forma ativa e estados; restaurar checkpoint coerente após reabrir. | A07; A10 | C-RF06: transições nos dois sentidos, após morte e reabertura; `RF06_transicoes`; C-SAVE. | Pendente implementação/teste. |
| RNF01 / S01 p. 4 | Para cada módulo integrado, localizar prompt, saída original, curadoria identificada, correção quando houver, teste e versão. Não fixar percentual de geração ausente da fonte. | A03 (método), atividades de código e A08; A11 | C-RNF01: auditoria de rastreabilidade; diário/matriz/commits, sem comparação manual. | D01 é precedente; módulos futuros pendentes. |
| RNF02 / S01 p. 4 | Inventário dos recursos finais identifica autor humano, fonte editável, ferramenta e uso; nenhum asset criativo ou narrativa final gerado por IA. | A04; integração A09; conferência A10 | C-RNF02: inventário e fontes humanas do pacote; autoria conferida pela equipe. | Recursos finais pendentes; diagramas técnicos A02 não são assets. |
| RNF03 / S01 p. 4 | Acessar aviso em UI/menu ou créditos do executável; conferir que lista os módulos realmente assistidos e a autoria/curadoria corretas. | A09; A10 | C-RNF03: captura `RNF03_transparencia` e relação com diário/inventário. | Aviso final pendente; texto final humano. |
| RNF04 / S01 p. 4 | Repetir percurso/ciclos na mesma máquina/configuração e versão; registrar FPS/tempo de quadro, memória, falhas e perda de estado; observar tendência após aquecimento. | A03 define protocolo; A10 mede; A11 analisa | C-RNF04: planilha/log de medições reais. Equipamento, duração, repetições e tolerâncias a aprovar; sem aprovação quantitativa antes disso. | Sem medição final; critérios numéricos pendentes. |
| RNF05 / S01 p. 4 | Abrir projeto e compilar com Godot .NET/C# das versões registradas, reproduzindo o pacote final. | A01 (base), A09; A10 | C-RNF05: log/versões do projeto final, reprodução por outro dev. | Base A01 validada; demo final pendente. |
| RNF06 / S01 p. 4 | Pacote completo Windows Desktop x86_64 inicia fora do editor e permite concluir o percurso aprovado. | A01 (fluxo), A09; A10 | C-RNF06: pacote identificado e captura `RNF06_executavel`; incluir dependências geradas. | Exportação A01 validada; demo final pendente. |

**Persistência é obrigação textual adicional de S01 p. 5–6**, associada a RF06/A07; não renumerar a fonte criando RF07. C-SAVE prevê: arquivo inexistente, arquivo válido, JSON inválido, ID/versão incoerente, morte antes/depois da absorção, retorno ao ponto seguro, obstáculos persistidos e fechar/reabrir. Evidência futura: `SAVE_retomada` com JSON controlado, versão e observado. Controles e atribuição humana são orientações de S02/S04/P02 para A09, sem inventar RNF07.

## 3. Percurso mínimo das três seções — proposta IA

Os nomes abaixo são **identificadores técnicos**, não narrativa ou nomes artísticos finais. Um único conjunto humano de pisos/cenário é reutilizado. Há um exemplar relevante de cada tipo copiável neste percurso mínimo; a quantidade fechada se refere a dois tipos, sem exigir inimigos extras.

| Seção | Entrada e ponto seguro | Meio | Saída e condição |
|---|---|---|---|
| `secao_01` | Entrada inicial e `seguro_01`, em piso estável antes de combate. | `inimigo_01_A`, derrotável só com ações básicas; após derrota, aquisição de A. | `obstaculo_01_A`, passagem elevada entre S1/S2; exige A equipada e uso do pulo duplo na primeira superação. |
| `secao_02` | Chegada além do primeiro bloqueio; `seguro_02`, alcançável sem novo combate. | `inimigo_02_B`, acessível usando movimento básico e A já adquirida; após derrota, aquisição de B. | `obstaculo_02_B`, barreira entre S2/S3; exige B equipada e investida para a primeira destruição. |
| `secao_03` | Chegada além da barreira; `seguro_03`, em área estável. | Trecho curto com os mesmos pisos; demonstra movimento e a possibilidade de voltar, sem terceiro bloqueio obrigatório. | `fim_03`, término técnico do percurso, sem chefe, missão, colecionável ou sistema de recompensa. |

```mermaid
flowchart LR
    S1["S1: entrada / seguro_01"] --> EA["inimigo_01_A: derrotar e absorver A"]
    EA --> O1["obstaculo_01_A: equipar A e usar pulo duplo"]
    O1 --> S2["S2: entrada / seguro_02"]
    S2 --> EB["inimigo_02_B: derrotar e absorver B"]
    EB --> O2["obstaculo_02_B: equipar B e usar investida"]
    O2 --> S3["S3: entrada / seguro_03"]
    S3 --> F["fim_03: fim do percurso"]
    S3 -. "retorno pelo bloqueio já aberto" .-> S2
    S2 -. "retorno pelo bloqueio já superado" .-> S1
```

### 3.1 Condições para não perder a progressão

1. Nenhuma habilidade é necessária para alcançar/derrotar o inimigo que a concede. O primeiro inimigo antecede O1; o segundo antecede O2. O1 deve impedir avanço por salto básico ou investida sem A; O2 deve impedir avanço com A. Dimensões/colisões serão verificadas na A07, não estão provadas por este desenho.
2. Marcar O1 superado somente ao concluir a transposição e aterrissar em área segura; liberar então a passagem de retorno associada ao próprio bloqueio. O2 fica aberto após a destruição. Não há terceira porta ou habilidade para voltar. A regra de chave vale para a primeira superação; um bloqueio permanentemente aberto não exige validar novamente a chave.
3. As conexões abertas são bidirecionais. Retornar por uma conexão define o ponto seguro da seção de destino e não refecha bloqueios nem remove aquisições. As três seções são o mesmo mapa lógico, não três biomas.
4. Após derrota sem absorção, permanece um alvo de absorção no local estável do inimigo. Ao trocar de seção, morrer ou carregar, esse estado pode ser reconstruído pela derrota registrada e ausência da habilidade. Assim, não é preciso ressuscitar o inimigo nem perder a habilidade para repetir a tentativa.
5. Adquirir A/B é permanente na partida/save; alternar só troca a habilidade ativa. Não existem cargas consumíveis definitivas ou perda aleatória de habilidade. Pouso restaura os usos por ciclo; não depende de item ou inimigo extra.
6. O ponto seguro pertence à seção, fica fora de dano e não é a posição exata em combate/no ar. A derrota do jogador o reposiciona em piso estável e preserva o progresso confirmado. O save nunca retoma dentro de parede, sobre bloqueio ou além de uma passagem ainda fechada.

## 4. Regras de combate, habilidades e reinício — propostas IA

As regras desta seção orientam os contratos futuros; nenhuma foi aprovada pelo simples fato de constar aqui. Seus parâmetros pendentes estão na seção 8.

### 4.1 Combate e absorção

| Regra | Contrato proposto | Verificação futura |
|---|---|---|
| R01 — Vida/dano | Estado de vida separado da UI, com `0 ≤ vidaAtual ≤ vidaMaxima`. Ataque básico causa dano ao inimigo; ataque/contato válido causa dano à protagonista; uma ação não aplica dano a cada quadro de sobreposição. Intervalo de dano, alcance, vida máxima e valores de dano ficam para curadoria/balanceamento da A05. | C-RF02: comparar estado e barra/contador, atacar repetidamente, testar contato e limite zero. |
| R02 — Derrota do inimigo | Vida zero desativa ataque/dano do inimigo e o coloca em estado derrotado absorvível. Antes disso, absorção não altera habilidades. Inimigo derrotado não concede habilidade automaticamente pelo mero dano. | C-RF02/C-RF03: tentativa em vivo e derrotado. |
| R03 — Absorção explícita | Comando de absorção, em alcance do derrotado, concede a habilidade do seu tipo e a equipa imediatamente. Usar comando simples, opção permitida por RF03, sem finalizador complexo. Não absorver à distância, durante morte ou de tipo não copiável. | C-RF03: fora/dentro do alcance; interromper por morte; conferir concessão única. |
| R04 — Aquisição idempotente | Conjunto de adquiridas não tem duplicatas. Tentar absorver alvo já consumido não cria recursos nem remove habilidades. Derrota, aquisição, habilidade ativa e aparência devem ficar coerentes antes de publicar o novo estado. | C-RF03/C-SAVE: repetir e fechar/reabrir antes/depois de absorver. |

### 4.2 Duas habilidades e formas

| Habilidade técnica | Aquisição e disponibilidade | Limite por ciclo proposto | Relação com bloqueio |
|---|---|---|---|
| A = `habilidade_A_pulo_duplo` | Tipo `tipo_A` em S1; permite um segundo salto no ar quando A estiver ativa. Movimento básico continua disponível em qualquer forma. | Um salto adicional entre pousos; restaurar ao tocar piso estável. Sem consumo persistente. Não renovar o salto ao alternar de forma no ar. | Primeira transposição de O1 só com A ativa e ação correspondente; posse sem equipar é insuficiente. |
| B = `habilidade_B_investida` | Tipo `tipo_B` em S2; comando de ação executa deslocamento horizontal curto com colisão nativa, quando B estiver ativa. | Uma investida por fase aérea, restaurada ao pousar; em solo, nova ação só após a anterior e seu intervalo. Duração, velocidade e intervalo pendentes. Trocar a forma não reinicia disponibilidade. | O2 só é destruído pela investida válida com B ativa; dano básico e pulo duplo não o abrem. |

**R05 — Habilidade ativa:** antes de qualquer absorção, `null` representa forma base. Após aquisição, apenas uma das habilidades adquiridas fica ativa. Troca por comando dedicado percorre adquiridas; quando não há nenhuma, não faz nada. Não descarta a outra aquisição, não cura e não renova ações já usadas no mesmo ciclo.

**R06 — Momento da troca:** aceitar troca em repouso/locomoção; durante ataque, absorção ou investida em curso, aguardar o término ou rejeitar a troca, sem resetar a ação. Recomenda-se rejeitar naquele instante para reduzir estados. A escolha final e o retorno visual ao jogador dependem de curadoria. Após morte/carga, o ator nasce em piso seguro, sem ação em andamento e com disponibilidade de ciclo restaurada.

**R07 — Representação:** habilidade ativa e aquisições pertencem ao estado lógico; sprites/animações humanos são representações desse estado, nunca a fonte da regra de acesso. Equipar A/B muda ação habilitada e representação de modo coerente. Dano não troca forma. Arte ausente não comprova RF04; até a A04 só cabem formas nativas de prototipagem autorizadas no AGENTS.

**R08 — Controles:** ações necessárias: mover, pular, atacar, absorver, usar B e alternar forma. Pulo duplo usa novo pressionamento de pulo. Teclas finais para ataque/absorção/investida/troca são **pendentes humanas**, a escolher sem conflito e documentar na A09. Não reutilizar um clique de UI como evidência de ação do personagem.

### 4.3 Contadores do modelo original

S07 contém `qt_uso` e `qt_uso_atual`, mas não estabelece que sejam cargas consumíveis, número de saltos ou outra limitação. O campo, isoladamente, não é uma decisão humana de gameplay. A recomendação é **não persistir esses contadores**: manter apenas disponibilidade transitória por salto/ação, reiniciada em pouso ou retorno seguro. Isso evita consumir a única chave antes de um bloqueio e dispensa recursos adicionais.

Se a equipe preferir cargas finitas, precisa definir recarga garantida e acessível antes de cada tentativa, depois de morte e em ambos os sentidos do retorno, além dos novos campos de save. Não implementar tal alternativa sem revisar o percurso/T01. O documento não aprova implicitamente esse acréscimo.

### 4.4 Morte, reinício e carregamento

| Evento | Vida/posição | Aquisições e habilidade ativa | Inimigos e obstáculos |
|---|---|---|---|
| Iniciar sem save | Vida máxima definida no catálogo; `secao_01`/`seguro_01`. | Nenhuma aquisição; ativa `null`; forma base. | Ambos inimigos vivos, ambos bloqueios fechados. |
| Receber dano não letal | Reduzir vida, atualizar UI pelo estado. Posição segue a física. | Preservar ambas as informações. | Preservar estados. |
| Morrer (`vidaAtual = 0`) | Interromper ações e dano; voltar ao ponto seguro corrente com vida máxima. Um único retorno por morte; sem sistema de vidas/slots. | Preservar todas as aquisições e a ativa; restaurar apenas os usos transitórios. | Preservar derrotas e bloqueios superados; derrotado sem aquisição volta como alvo absorvível. Não restaurar sua capacidade de dano. |
| Carregar save válido | Restaurar a vida positiva salva e o ponto seguro da seção salva; não curar pelo simples carregamento. | Restaurar adquiridas e ativa; recompor visual e resetar ações transitórias no piso. | Reconstituir conjuntos persistidos e alvos pendentes de absorção. |
| Reiniciar após morte | É o retorno ao ponto seguro descrito acima, não uma nova partida que apaga habilidades. | Preservar progresso confirmado. | Preservar estados confirmados. |

Salvar a vida zero como estado de retomada é proibido nesta proposta: o tratamento da morte produz primeiro um estado de retorno válido. Vida máxima, valores de dano e tempos são **pendentes humanas**; o JSON da seção 6 é apenas ilustrativo.

## 5. Conferência e adaptação dos casos de uso

S01 p. 5/S06 mostram o ator **Jogador** associado a UC01 Movimentar Cyra, UC02 Combater Inimigo, UC03 Absorver Habilidade, UC04 Interagir com Obstáculo e UC05 Transitar de Seção. UC03 inclui Alterar Estado/Aparência; Superar Obstáculo aparece como extensão condicionada de UC04. Os IDs e intenções são preservados.

O esquema a seguir é um **mapa técnico de interações proposto**, não uma reedição silenciosa do UML original. As relações de inclusão/extensão são explicadas no texto, sem depender da direção ambígua da seta original.

```mermaid
flowchart TB
    J["Jogador"] --- UC01["UC01: Movimentar Cyra"]
    J --- UC02["UC02: Combater inimigo"]
    J --- UC03["UC03: Absorver habilidade"]
    J --- UC04["UC04: Interagir com obstáculo"]
    J --- UC05["UC05: Transitar de seção"]
    UC03 --> EST["Resultado obrigatório: atualizar estado e aparência"]
    UC04 --> COND{"Ativa correta e ação válida?"}
    COND -->|sim| SUP["Superar obstáculo"]
    COND -->|não| BLOQ["Manter bloqueio fechado"]
    J --- TROCA["Apoio proposto: alternar habilidade adquirida"]
    J --- RET["Apoio proposto: retomar partida existente"]
    UC05 -. "persistência interna" .-> SAVE["Salvar progresso local"]
    EST -. "persistência interna" .-> SAVE
    RET --> LOAD["Validar e carregar save único"]
```

| Caso preservado / apoio | Pré-condição | Fluxo e pós-condição | Alternativa relevante / vínculo |
|---|---|---|---|
| UC01 | Ator vivo, seção carregada. | Mover, pular, cair e colidir com física nativa. | Não atravessar piso/parede; segundo salto só com A ativa. RF01/RF04. |
| UC02 | Jogador e inimigo vivos, ação/alcance válidos. | Aplicar dano; atualizar vida real e UI; inimigo a zero vira derrotado absorvível. | Sem dano de inimigo derrotado ou ação duplicada por quadro. RF02. |
| UC03 | Jogador vivo, inimigo derrotado e no alcance. | Comando concede uma habilidade, equipa e altera representação; salva estado coerente quando A07 existir. | Vivo, fora de alcance ou já absorvido não duplicam aquisição. RF03/RF04. |
| UC04 | Bloqueio ainda não superado. | Avaliar habilidade ativa e ação; superar somente se correspondentes. | Sem/errada: manter fechado. Já superado: manter aberto, sem gastar recursos. RF05. |
| UC05 | Chegar à conexão liberada entre seções. | Carregar destino e checkpoint seguro, mantendo aquisições/forma/derrotas/obstáculos; persistir destino coerente. | Falha de carga não confirma transição nem salva destino incompleto. RF06/C-SAVE. |
| Apoio: trocar forma | Há habilidade adquirida e nenhuma ação incompatível em curso. | Alterar apenas ativa e visual; manter vida/aquisições. | Não habilitar forma ainda não adquirida nem renovar usos. RF04. |
| Apoio: morrer/retomar | Vida zero ou abertura da demo com save. | Morte segue a tabela 4.4; carga usa validação da seção 6. | Arquivo inexistente/inválido tem tratamento explícito; sem apagar progresso válido por morte. RF02/RF06/C-SAVE. |

Salvar é responsabilidade interna de persistência, não um novo botão obrigatório ou um novo ator. Aviso/controles/créditos são interações de A09 associadas a RNF03 e às orientações do grupo, fora dos UC01–UC05 originais. Nenhum texto final do jogo é produzido aqui.

## 6. Modelo do save local único — proposta IA

### 6.1 Leitura do SQL e adaptação proposta

`Untitled.sql` é referência de modelagem, não um script a executar. Contém `SAVE_JOGADOR`, `SECAO`, `HABILIDADE`, `OBSTACULO_ESTADO` e quatro chaves estrangeiras. A sintaxe SQL Server (`GO`, `nvarchar`, `binary`) não determina tecnologia de persistência do jogo. Nada será convertido para banco, servidor ou múltiplos slots.

| Origem S07 | Natureza | Adaptação proposta |
|---|---|---|
| `SECAO.id_secao`, `nome_secao` | Catálogo estático. | IDs estáveis das três seções e seus pontos seguros/posições em definição do jogo; nomes artísticos humanos fora do save. |
| `HABILIDADE.id_habilidade`, `nome_habilidade`, `qt_uso` | Definição estática, exceto a interpretação não especificada de uso. | IDs e parâmetros de A/B no catálogo; limites transitórios segundo 4.2; retirada de `qt_uso` sujeita a revisão. |
| `HABILIDADE.is_desbloqueada` | Progresso do jogador misturado à definição. | Conjunto `habilidadesAdquiridas` do save; ausência significa não adquirida. |
| `SAVE_JOGADOR.id_save` | Identidade de registro relacional. | Sem necessidade de chave de slot: há um único arquivo. `versaoFormato` identifica o contrato, não um segundo save. |
| `pontos_vida`, `id_secao_atual`, `id_habilidade_ativa` | Progresso. | `vidaAtual`, `secaoId`, `habilidadeAtivaId`; acrescentar `pontoSeguroId`. |
| `SAVE_JOGADOR.qt_uso_atual` | Semântica não definida. | Não persistir na proposta sem cargas; estado de ação transitório é reconstruído em piso seguro. |
| `OBSTACULO_ESTADO.id_obstaculo`, `id_secao`, `id_habilidade_requerida` | Identidade/regra estática. | Catálogo fixa localização e chave de cada obstáculo. |
| `OBSTACULO_ESTADO.is_superado` | Progresso misturado à definição. | Conjunto `obstaculosSuperados`, sem duplicatas; ausente = fechado. |
| Inimigos relevantes e posição de retorno | Ausentes no SQL, exigidos textualmente em S01 p. 5–6. | Conjunto `inimigosRelevantesDerrotados`; catálogo liga inimigo→seção→habilidade→posição segura do alvo absorvível; checkpoint referencia posição estável. |

A posição é representada por **seção + ponto seguro**, resolvida em coordenadas estáticas aprovadas na A07. Não salvar coordenadas arbitrárias no ar. Se a equipe desejar posição exata, será alteração explícita deste contrato, com validação adicional, não algo já contido no SQL.

### 6.2 Identificadores estáveis e separação de dados

| Categoria | IDs técnicos propostos | Vínculo estático |
|---|---|---|
| Seções / pontos seguros | `secao_01`/`seguro_01`; `secao_02`/`seguro_02`; `secao_03`/`seguro_03` | Um checkpoint por seção, no lado de chegada seguro; coordenadas definidas no mapa futuro. |
| Habilidades | `habilidade_A_pulo_duplo`; `habilidade_B_investida` | A/B e respectivas ações/formas humanas. |
| Tipos / exemplares relevantes | `tipo_A`/`inimigo_01_A`; `tipo_B`/`inimigo_02_B` | S1 concede A; S2 concede B; exemplares têm posição estável no catálogo. |
| Obstáculos | `obstaculo_01_A`; `obstaculo_02_B` | O1 em S1→S2 requer A; O2 em S2→S3 requer B. |

IDs não dependem do nome de arquivo, sprite, caminho de nó ou nome exibido. Renomear arte ou reorganizar nós não muda o ID de progresso. Mudar esses IDs após saves distribuídos exigirá decisão explícita sobre compatibilidade; migração não é implementada nesta atividade.

```mermaid
classDiagram
    class CatalogoEstatico {
        secoesEPosicoesSeguras
        habilidadesEParametros
        inimigosEHabilidadesConcedidas
        obstaculosEChavesRequeridas
        vidaMaxima
    }
    class SaveLocalUnico {
        int versaoFormato
        string secaoId
        string pontoSeguroId
        int vidaAtual
        string[] habilidadesAdquiridas
        string habilidadeAtivaId_ou_null
        string[] inimigosRelevantesDerrotados
        string[] obstaculosSuperados
    }
    class EstadoTransitorio {
        velocidade
        ataqueEmCurso
        saltosUsadosNoCiclo
        investidaUsadaNoCiclo
        intervaloDeDano
    }
    SaveLocalUnico --> CatalogoEstatico : referencia IDs e valida regras
    EstadoTransitorio ..> SaveLocalUnico : reconstruido ao retomar no piso
```

Sprites, animações, áudio, gravidade, regras de dano, vida máxima, alturas, habilidades requeridas e coordenadas de checkpoint são dados estáticos. Não duplicá-los no save. Vida atual, seção/checkpoint, aquisições, ativa, derrotas e superações são progresso. UI, velocidade e estado de animação não são persistidos.

### 6.3 Campos e invariantes

Arquivo proposto: `user://cyra_save.json`, único, local e estruturado. O caminho `user://` será resolvido pela Godot na A07; nenhum arquivo real de save é criado nesta entrega.

| Campo | Validação proposta |
|---|---|
| `versaoFormato` | Inteiro `1` para este contrato ilustrativo; versão desconhecida é incompatível, sem migração automática implícita. |
| `secaoId` / `pontoSeguroId` | IDs do catálogo; ponto pertence à seção e a um lado alcançável com o progresso salvo. S2 exige O1 superado/A adquirida; S3 exige O1 e O2 superados/A e B adquiridas. |
| `vidaAtual` | Inteiro positivo até a vida máxima do catálogo. Zero não é retomada válida; morte é resolvida antes da gravação. |
| `habilidadesAdquiridas` | Conjunto sem duplicatas, subconjunto de {A,B}; na rota proposta B implica A. |
| `habilidadeAtivaId` | `null` apenas quando não há aquisições; caso contrário, uma das adquiridas. Representação deriva desse valor. |
| `inimigosRelevantesDerrotados` | IDs únicos de exemplares do catálogo; ter A/B implica a derrota de seu exemplar. Derrota sem aquisição é válida e reconstrói alvo absorvível. |
| `obstaculosSuperados` | IDs únicos de O1/O2; O1 implica A adquirida, O2 implica B adquirida e O1 superado no percurso proposto. Aberto não volta a fechar por troca/morte/carga. |

Validar a estrutura inteira e essas relações **antes** de aplicar o estado. Não aceitar habilidade ativa desconhecida, checkpoint incoerente ou avanço além de gate sem pré-requisitos. Duplicatas, tipos errados, campo obrigatório ausente ou inconsistência semântica invalidam a carga nesta proposta; não corrigir silenciosamente inventando aquisições. Campos extras desconhecidos podem ser ignorados apenas com `versaoFormato` reconhecida e estado obrigatório válido.

### 6.4 Quando salvar e carregar

**Proposta IA:** carregar uma vez ao iniciar/retomar, antes de instanciar o progresso do mapa; trocar seção não relê arquivo antigo nem desfaz estado atual. Gravar após cada evento confirmado, usando uma fotografia coerente do estado em memória:

1. Entrada inicial/ponto seguro e chegada concluída a outra seção: salvar seção e checkpoint de destino, preservando vida corrente e progresso.
2. Derrota relevante: salvar derrota mesmo antes da absorção; ao retomar, reconstruir o alvo absorvível se a habilidade ainda não foi adquirida.
3. Absorção e troca aceita de habilidade: salvar aquisições/ativa juntas. O checkpoint permanece no piso seguro anterior; não é a posição exata do evento.
4. Superação confirmada de bloqueio: persistir abertura; no cruzamento, atualizar seção/checkpoint somente após destino carregado com sucesso.
5. Dano não letal: salvar vida corrente sem transformar o local do dano em checkpoint. Morte: concluir o retorno ao ponto seguro com vida máxima e só então salvar; não há gravação intermediária de vida zero.

Persistir nos eventos evita depender apenas de um fechamento normal do aplicativo. Para falha de escrita, conservar o estado em memória e o último arquivo válido, informar que o novo progresso não foi salvo e tentar no próximo evento previsto. Não alegar gravação concluída. A A07 deve gravar integralmente e substituir o arquivo somente após a nova serialização estar válida; eventual arquivo temporário é técnico/transitório, não outro slot ou histórico de partidas.

| Condição de carga | Comportamento recomendado — ainda proposto |
|---|---|
| Arquivo inexistente | Criar estado inicial em memória e salvar em `secao_01`/`seguro_01`, vida máxima, sem habilidades/derrotas/obstáculos. |
| Arquivo válido | Restaurar todo o progresso de forma consistente e nascer no ponto seguro com a vida salva; recompor UI/forma após estado lógico. |
| JSON ilegível, IDs/estado inválidos ou versão incompatível | Não aplicar estado parcial; avisar falha e iniciar estado base em memória. Não truncar o arquivo durante a leitura. A próxima gravação válida da nova sessão substitui o único save; a equipe deve aprovar expressamente esta política de recuperação, pois não recupera progresso corrompido e não mantém backups/slots. |
| Erro de acesso/leitura por permissão | Iniciar estado base somente com indicação de falha; não declarar arquivo inexistente ou gravação bem-sucedida. Nova gravação poderá falhar, mantendo a indicação. |

Não há nuvem, banco, sincronização, seletor de slots ou menu de gerenciamento de saves. Reinício por morte conserva o progresso da sessão; arquivo corrompido não garante recuperar aquisições perdidas e por isso é tratado como falha, não como carregamento aprovado.

### 6.5 Exemplo ilustrativo de JSON

**Exemplo fictício, não extraído do jogo e não gerado como save real.** Representa a partida em S2 após adquirir A/B, com B ativa, O1 aberto e O2 ainda fechado. Supõe, apenas para o exemplo, vida máxima estática de 3; `vidaAtual: 2` não decide o balanceamento.

```json
{
  "versaoFormato": 1,
  "secaoId": "secao_02",
  "pontoSeguroId": "seguro_02",
  "vidaAtual": 2,
  "habilidadesAdquiridas": [
    "habilidade_A_pulo_duplo",
    "habilidade_B_investida"
  ],
  "habilidadeAtivaId": "habilidade_B_investida",
  "inimigosRelevantesDerrotados": [
    "inimigo_01_A",
    "inimigo_02_B"
  ],
  "obstaculosSuperados": ["obstaculo_01_A"]
}
```

## 7. Conferência documental T01 e rastreabilidade prevista

T01 corresponde à **revisão documental humana da A02**, não a um teste de mecânicas já implementadas. Resultado observado e situação no diário ficam `[Pendente execução humana]`. Executar a revisão com S01/S02 e este documento, registrando a versão revisada, participantes efetivos e decisões. Não atribuir autor/revisor por suposição.

Roteiro de T01:

1. Conferir cada transcrição RF/RNF contra S01 p. 3–4 e separar critérios propostos. Confirmar que os 12 IDs têm atividade, cenário e evidência futura.
2. Explicar S1→A→O1→S2→B→O2→S3→fim e o retorno em ambos os sentidos; verificar que nenhum inimigo depende da habilidade que concede.
3. Simular em papel: sem chave, chave adquirida mas errada/inativa, chave ativa correta; desgaste por uso; troca de forma no ar; morte antes/depois de absorver; derrota sem aquisição seguida de carga.
4. Conferir UC01–UC05, separar estados estáticos/transitórios/progresso, relacionar cada adaptação ao SQL e conferir todos os campos do JSON.
5. Simular carga inexistente, válida, inválida e falha de escrita; conferir ausência de perda definitiva por morte e coerência de checkpoints/obstáculos. Distinguir a recuperação de save corrompido, que não promete recuperar dados.
6. Registrar escolhas/rejeições e parâmetros pendentes da seção 8. Verificar que não houve implementação ou alteração dos arquivos do jogo. Só marcar T01/A02 aprovados após a revisão humana real; aprovação do documento não aprova C-RFxx/C-RNFxx/C-SAVE.

Evidência sugerida, ainda inexistente: `docs/evidencias/T01_A02_revisao.md`, contendo versão, data real, participantes, decisões, pendências e ligação à versão integrada. As futuras evidências de mecânicas listadas na seção 2 não foram produzidas aqui. Não são solicitadas capturas fictícias de um mapa que ainda não existe.

## 8. Decisões para curadoria e encaminhamento

| ID | Tema / recomendação | Classificação atual | Revisão sugerida, sem designar aprovação |
|---|---|---|---|
| DEC01 | Escopo de três seções, dois tipos/duas habilidades, dois bloqueios, save único; assets/narrativa humanos; sem comparação manual independente. | **Registrada** em S02/S03/P02. | Equipe conferir fidelidade e informar alteração metodológica no texto final/orientação, sem reabrir escopo. |
| DEC02 | Ambiente A01 e T00 aprovados por Caio/Lucas nas versões da seção 1.2. | **Registrada** em S05/Git. | Preservar D01/T00 e evidências. |
| DEC03 | A=pulo duplo, B=investida; percurso e checkpoints técnicos da seção 3, abertura persistente e retorno bidirecional. | **Proposta IA; aprovação pendente.** | Caio/Lucas verificarem viabilidade; Victor conferir volume e reutilização dos recursos humanos. |
| DEC04 | Sem cargas permanentes; retirar contadores do save; um salto extra e limite de investida por ciclo; trocar forma não restaura usos. | **Proposta IA; aprovação pendente.** | Caio/Lucas confrontarem `qt_uso`/`qt_uso_atual` com intenção humana dos modelos; equipe aprovar regra de recarga. |
| DEC05 | Absorção por comando de derrotado, aquisição permanente, equipar ao adquirir, uma ativa, alvo absorvível reconstruído após derrota sem aquisição. | **Proposta IA; aprovação pendente.** | Caio/Lucas simularem estados negativos e interrupções; Victor conferir que não implica animação/finalizador extra. |
| DEC06 | Morte retorna ao checkpoint com vida máxima e mantém aquisições/ativa/derrotas/bloqueios; carga válida restaura vida positiva salva. | **Proposta IA; aprovação pendente.** | Caio/Lucas conferirem diferença entre morte, retomada e nova sessão sem save. |
| DEC07 | JSON único, IDs estáveis, campos/invariantes, pontos seguros, eventos de gravação e política de arquivo inválido da seção 6. | **Proposta IA; aprovação pendente.** | Lucas/Caio conferirem contrato e recuperação; equipe aceitar explicitamente que corrupção não recupera progresso nem mantém backups. |
| DEC08 | Ajustar casos de uso textualmente e separar catálogo/progresso do SQL, sem alterar originais. | **Proposta IA; aprovação pendente.** | Equipe conferir relações e adequação dos diagramas ao texto antes de substituir modelos em entregas futuras. |
| DEC09 | Valores de vida/dano, alcance, tempos de ação/dano, velocidade/duração de investida, dimensões de bloqueio e teclas finais. | **Pendente definição humana.** | Caio/Lucas antes da implementação correspondente; Victor participa de legibilidade/volume artístico. O JSON não fixa esses valores. |
| DEC10 | Equipamento, percurso de medição, duração/repetições e limites quantitativos de estabilidade. | **Pendente definição humana na A03.** | Caio/Lucas, com registros de Victor; não declarar RNF04 aprovado por ausência de erro na A01. |
| DEC11 | Textos finais, nomes artísticos, sprites, animações, sons e atribuições concretas. | **Pendente autoria humana A04/A09.** | Victor/equipe; IDs técnicos e diagramas deste documento não são narrativa final. |

### Lista curta para aprovar a A02

- [ ] Conferir com a fonte os 12 requisitos, páginas e divergências metodológicas, sem mudar os IDs.
- [ ] Aprovar ou corrigir percurso, habilidades, limites de uso e retorno; explicar sem contradições os dois bloqueios e o fim.
- [ ] Fechar absorção, forma ativa, morte e retomada; simular derrota sem absorção e ausência de chave para evitar travamento.
- [ ] Aprovar adaptação dos UC/modelo SQL e contrato do save, incluindo arquivo inválido e falha de escrita.
- [ ] Identificar parâmetros ainda necessários para cada implementação e critérios de desempenho a fechar na A03; não antecipar aprovação dos testes futuros.
- [ ] Registrar participantes reais, decisões, resultado T01 e versão humana integrada; manter D02 original preservado.

**Encaminhamento após curadoria:** A04 produz os recursos humanos mínimos; A05 trata RF01/RF02 e reinício; A06 implementa RF03/RF04; A07 integra bloqueios, mapa e save; A09 apresenta controles/transparência e exporta a demo; A08/A10 registram revisão e testes quando ocorrerem. Esses são vínculos de planejamento, não autorização de implementação nesta entrega.

## 9. Preservação e limites desta saída

Registro [D02/T01 no diário](Diario_Experimento_Cyra.md), [P02 integral](prompts/P02_A02_prompt_integral.md) e índice em [Prompts utilizados](Prompts_Utilizados.md). Saída documental original identificável em [D02_A02.zip](saidas_originais/D02_A02.zip), com [manifesto SHA-256](saidas_originais/D02_SHA256.txt) e [hashes das fontes consultadas](saidas_originais/D02_fontes_SHA256.txt).

O arquivo preserva esta proposta e os registros documentais produzidos antes de futuras revisões humanas. Conferência automática de links/estrutura não é aprovação da equipe. Tempos de aprendizagem, geração e revisão não foram medidos; não inventar responsáveis, achados, execução de testes ou aprovação. Nenhum commit ou envio ao GitHub é realizado por esta tarefa.
