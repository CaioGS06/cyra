# T05 — Movimento, combate, vida e reinício A05

**Preparado em:** 30/10/2026. **Vínculos:** D06/P10, C-RF01/C-RF02 da A02 e reinício de apoio A05. **Base Git consultada:** `cf5ba4a`; implementação ainda sem commit. **Curadoria humana:** `[Pendente execução humana]`. Caio/Lucas são revisores previstos; participação efetiva, aprovação e tempos não foram informados e não são atribuídos pela IA.

## 1. Estado automático observado — separado da revisão humana

- Compilação zero avisos/erros; importação/carregamento da sala e exportação final Windows concluídos.
- [56 checagens de comportamento](T05_A05_automatico/behavior_results.json), [34 de integração](T05_A05_automatico/integration_checks.json), sem falhas finais. Física real da engine com entrada simulada/fixtures, em execução sem janela na máquina de Caio pela IA.
- A01: [14 verificações de regressão](T05_A05_automatico/a01_regression.log) passaram; não altera o resultado histórico de T00.
- Quatro mortes/retornos na mesma sessão do coletor (três por contato, uma fixture letal), além de reinício manual; sem nós extras ou emissões duplicadas nas verificações. Vida máxima e inimigo restaurados.
- Modo comum sem sessão; falha de escrita simulada não interrompeu o jogo. D05 de máquina explícita/coleta ausente preservado; pacote errado rejeitado.
- Release atual: pacote `faf55c4951e9ab859d8c13badebd21c7aeeeaa3001a797436f3e3274eac0e029`; execuções sem janela com coleta íntegra, Caio/NaoInformada, cenário A05, sem erros/avisos.
- Tentativas/correções da própria IA estão preservadas e descritas em [A05](../A05_Movimento_Combate_Vida.md). Não são intervenção humana. A01/A03 anteriores, inclusive cinco F9/nenhum pulo de Lucas, permanecem intactos.

**Limites:** nenhuma validação gráfica/humana nova; texto da UI lido em teste não comprova legibilidade; fixtures isolam comportamentos, não são uma partida humana completa. Não é benchmark gráfico nem medição final de RNF04. `summary.json` não atribui aprovação automática.

## 2. Roteiro humano e resultado esperado

Usar o [guia A05 de 12 passos](../Guia_Lucas_Testes.md), pacote completo em `build/a05-test`, CMD atual e seleção correta da máquina. Jogar, F9 após cada etapa e relato curto. Se esquecer marca/faltar evento, registrar a lacuna; não preencher com suposição.

Roteiro de revisão em grupos:

1. Início/vida real; andar nos dois sentidos, colidir com paredes e pular/cair/pousar sem salto extra.
2. Ataque fora/dentro do alcance e para ambos os lados; segurar/pressionar repetidamente respeita janela e intervalo; máximo um acerto no alvo por ataque.
3. Receber dano com intervalo; indicador acompanha vida real, sem decidir regras; chegar a zero não deixa vida negativa.
4. Atordoar inimigo e aguardar/encostar/atacar novamente: sem dano, recuperação por tempo, remoção ou absorção.
5. Reinício manual e morte por contato em outro ciclo: ponto seguro, vida máxima e inimigo restaurado; repetir morte e verificar ausência de duplicações/log novo por morte.
6. Conferir legibilidade, proposta provisória e código; registrar se nenhuma correção for necessária. Conferir cenário A05, F9 e coleta, sem exigir ao executor transcrever métricas.

## 3. Checklist humano — ainda não executado

- [ ] Movimento, salto, queda, piso e paredes.
- [ ] Alcance, direção, janela/intervalo, segurar e repetir ataque.
- [ ] Dano espaçado e correspondência vida real/indicador.
- [ ] Atordoamento sem dano posterior nem recuperação automática.
- [ ] Morte, retorno seguro/vida máxima e reinício do inimigo, repetidos.
- [ ] Legibilidade e adequação dos valores provisórios no Inspector.
- [ ] Coleta continua na morte, marcadores F9 e controles sem conflito; cenário/pacote/máquina corretos.
- [ ] Código lido; achados/decisão registrados, inclusive “sem correção necessária”, se for o caso.

## 4. Preenchimento após execução/revisão real

| Campo | Registro humano |
|---|---|
| Executor/revisor efetivo, máquina, data e versão/pacote | |
| Resultado observado e etapa/F9 ou lacuna | |
| Achados, decisão, ajustes humanos ou pedidos de correção à IA | |
| Reteste e evidência, quando necessário | |
| Tempo de aprendizagem/revisão/correção, se medido; senão “não medido” | |
| Situação humana do T05 e limitações aceitas explicitamente | |
| Versão integrada/commit após curadoria, quando existir | |

**Resultado Observado humano:** `[Pendente execução humana]`.

**Situação humana:** `[Pendente execução humana]`.

Sugestões de captura, **não produzidas nesta entrega**: vida antes/depois e inimigo atordoado, com versão/executor. Guardar nova sessão inteira (`package.json`, `execution.json`, `session.jsonl`, `summary.json`, `engine.log`, `relato.txt`) sem sobrescrever as tentativas anteriores. Não exigir alteração artificial do código para comprovar revisão.
