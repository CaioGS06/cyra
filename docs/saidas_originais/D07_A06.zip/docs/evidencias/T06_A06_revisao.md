# T06 — A06 / C-RF03 e C-RF04

Preparado pela IA em 03/11/2026, D07/P14; base 4253d7c. **Pendente execução/revisão humana**. RF04 parcial: só representação técnica, sem recursos humanos disponíveis. T03 permanece alias histórico da revisão A03; T05 não foi reaberto.

## Resultados automáticos separados

57 comportamentos A06, 56 A05 e 14 A01 passaram; 18 verificações de integração passaram. [Evidências](T06_A06_automatico/integration_checks.json), [A06](../A06_Mimetismo_Habilidades_Aparencia.md). Entrada simulada/fixtures/execução sem janela na máquina de Caio pela IA, não teste humano. Mesmo coletor durante três mortes e um R. Build/export/release observados, sem erro na rodada final. Métricas headless não aprovam desempenho gráfico. Marca F9 não aprova etapa.

## Roteiro e checklist humano

Seguir [guia atual A06](../Guia_Lucas_Testes.md), 16 etapas pequenas, F9 e relato breve; sem editar cenas/JSON ou alterar segurança. Partida nova exige fechar e reabrir; R preserva aquisições. Pré-condições, ações e esperados estão no guia, complementados pelas fixtures identificadas.

- [ ] Absorção rejeitada vivo/longe, aceita atordoado, sem duplicação/dano posterior.
- [ ] Aquisição A/B com equipamento imediato; troca só adquiridas.
- [ ] Pulo extra/investida respeitam limites, pouso restaura e troca não renova.
- [ ] Reabsorção não cura/renova usos e mantém ativa atual.
- [ ] Ataque/absorção/investida rejeitam troca; simultâneos não deixam fila oculta.
- [ ] Morte com A/B preserva aquisições/ativa, restaura vida/usos e reinicia inimigos.
- [ ] HUD/forma técnica acompanham lógica; legibilidade conferida; arte humana pendente.
- [ ] Código/Inspector, parâmetros provisórios, logs, F9 e pacote revisados.

| Campo | Preencher somente após ocorrência real |
|---|---|
| Executor, revisor de código e máquina efetivos | Pendente confirmação humana |
| Data, versão/base+diff, pacote/sessão | Pendente execução humana |
| Resultado observado, etapas/F9 e lacunas | Pendente execução humana |
| Achados, decisão, correção (ou nenhuma necessária) e autor real | Pendente revisão humana |
| Reteste/evidência quando necessário | Pendente quando aplicável |
| Esforço de aprendizagem/revisão/correção/teste | Não medido; informar se aferido |
| Situação humana e limites aceitos explicitamente | Pendente aprovação humana |
| Commit integrado após curadoria | Pendente; nenhum commit automático |

Capturas sugeridas, **não produzidas**: T06_A06_A_adquirida.png, T06_A06_B_ativa.png, T06_A06_antes_morte.png e T06_A06_retorno.png; identificar executor/versão. Enviar sessão inteira e relato; leitura de código deve ser confirmada separadamente de jogar. Caio e Lucas são destinatários da revisão, não participantes já registrados nesta A06.
