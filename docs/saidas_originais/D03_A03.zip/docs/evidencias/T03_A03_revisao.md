# T03 — Ficha preparada para revisão documental da A03

**Preparada em:** 22/10/2026, pela IA. **Documento:** [A03 — proposta de protocolo](../A03_Protocolo_Avaliacao_Curadoria.md). **Vínculos:** D03/P04. **Estado:** `[Pendente execução humana]`. Esta ficha é um roteiro vazio, não comprovação de revisão/medição. T03 fica reservado a esta finalidade e não pode ser reutilizado para teste de mecânica.

P03 já identifica as decisões humanas da A02; o novo prompt é P04. T02 não foi atribuído nesta entrega. Preservar T00/T01 e originais D01/D02.

## Identificação a preencher na revisão real

| Campo | Registro humano |
|---|---|
| Data e horários reais / duração, somente se medida | |
| Participantes efetivos e respectivas funções | |
| Versão do protocolo e commit/base examinada | |
| Achados, decisões e correções documentais realizadas | |
| Resultado observado da revisão | |
| Situação após revisão e pendências remanescentes | |
| Versão humana integrada, quando existir | |

## Roteiro ainda não executado

- [ ] Conferir vínculo aos 12 RF/RNF/cenários A02 sem duplicação e sem reabrir decisões de gameplay; registrar divergência da persistência original.
- [ ] Conferir estados de teste/requisito, casos bloqueados/inconclusivos, rastreabilidade e denominadores.
- [ ] Simular documentalmente o registro de achado, intervenção humana/edição por IA e reteste, sem inserir dados como se fossem execução real.
- [ ] Conferir PROG, CONT, SAVE e DIAG: estado inicial, manutenção/reset do mundo, pontos comparáveis, foco e processos separados.
- [ ] Confirmar máquina e condições de medição, duração/repetições, método viável e limites propostos; apontar dependências do piloto futuro.
- [ ] Conferir distinção de Private Bytes/working set/memória da engine/tempo de CPU/FPS e limites das amostras por segundo.
- [ ] Conferir esforço por etapa, reunião conjunta e ausência de tempo retrospectivo inventado; manter os 33 min relatados na A02 intactos.
- [ ] Registrar conclusão e versão humana; não aprovar cenários de mecânicas ou RNF04 pela aprovação do protocolo.

## Decisões metodológicas a preencher

| Tema | Decisão humana / responsável real |
|---|---|
| Máquina de referência | |
| Perfil: build, janela/resolução, renderizador, VSync/limite, energia e instrumentação | |
| Aquecimento, duração, repetições e pacing do piloto | |
| Método de coleta, contadores/PID, alternativa e limitações | |
| Limites operacionais de aceitação | |
| Participantes da revisão e funções na futura coleta/conferência | |

**Resultado observado:**

**Aprovação/pendências após revisão:**

Somente preencher após a revisão humana real. A existência deste arquivo não altera a situação pendente de T03 nem constitui execução de medições.
