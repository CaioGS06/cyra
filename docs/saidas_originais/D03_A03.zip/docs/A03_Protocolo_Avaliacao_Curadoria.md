# A03 — Protocolo de avaliação técnica e curadoria humana

**Data real da preparação:** 22/10/2026, America/Sao_Paulo. **Versão documental:** D03/P04. **Revisão reservada:** T03. **Estado:** proposta da IA, pendente de revisão humana; não é método adotado nem resultado da demo. A janela planejada de 16–20/10 não foi usada como data de execução nem alterada.

## 1. Base, decisões vigentes e identificação

Foram consultados [AGENTS](../AGENTS.md), [cronograma](Cronograma_Cyra_15-10_a_23-11-2026.md), [guia](Guia_atividades_Cyra_2026.md), [A02 aprovada](A02_Escopo_Requisitos_Modelos.md), [T01](evidencias/T01_A02_revisao.md), [diário principal](Diario_Experimento_Cyra.md), [template metodológico inicial](Diario_Experimento_IA.md), [prompts](Prompts_Utilizados.md), [README](../README.md) e Git local. A02 integrada em **`f1453934c0be612ae8f5c70515820624d15478bd`**, conferida no histórico; esse commit contém a revisão e a aprovação documental T01. As atualizações de hash nesta entrega se limitam aos campos de versão de trabalho ainda pendentes da A02.

A matriz dos 12 RF/RNF, redações originais e páginas da fonte ficam na **seção 2 da A02**; aqui não são duplicadas. A fonte primária continua sendo o PDF assinado indicado na seção 1 da A02, sem substituição por relatório homônimo. Não foi necessária nova interpretação de suas exigências nesta tarefa. As referências técnicas externas da seção 10 sustentam apenas a coleta, não criam requisitos do jogo.

### 1.1 Decisões já registradas — não reabertas

- Estudo de caso do processo assistido, com atendimento aos requisitos, defeitos, intervenções humanas, retrabalho, arquitetura, estabilidade e desempenho. Sem versão manual independente ou comparação de produtividade com desenvolvimento manual; sem superioridade da IA presumida.
- A01/T00 aprovadas por Caio/Lucas; A02/T01 aprovadas documentalmente com ajustes. Isso não comprova atendimento dos requisitos da **demo final** nem desempenho de uma demo ainda não implementada.
- Pulo duplo e investida, aquisições permanentes, uma habilidade ativa; zero de vida do inimigo produz atordoamento sem prazo até comando de absorção ou reinício.
- Transições mantêm inimigos/obstáculos em memória. Morte e reabertura reiniciam o mundo inteiro. Morte mantém habilidades/forma ativa e retorna ao ponto seguro da seção atual com vida máxima.
- Save único contém versão do formato, seção, ponto seguro, vida atual, habilidades adquiridas e ativa. **Não contém inimigos nem obstáculos.** Carga válida restaura a vida salva, sem curar pelo simples carregamento.
- A exclusão dos estados do mundo altera a persistência descrita na fonte primária, p. 5–6. A equipe reconheceu a mudança em T01; a análise final deve explicitá-la. Não renomear isso como atendimento integral à persistência original ou criar RF07 para esconder a divergência.
- Assets e narrativa finais são humanos; vida lógica é separada da UI e habilidade lógica é separada do sprite. Escopo e física nativa permanecem conforme AGENTS.

### 1.2 IDs e preservação

O índice já contém P01, P02 e **P03, dedicado às decisões humanas da A02**. A solicitação atual pede o próximo ID e também menciona P03 no encerramento. Para cumprir a preservação sem colisão, o prompt atual é registrado integralmente como **P04**, ligado a D03/A03. P03 permanece intocado.

T00/T01 já existem; T02 não está atribuído no diário consultado. A instrução final solicita **T03**, que fica reservado exclusivamente à **revisão documental da A03**. T02 não é criado nem marcado como executado. Futuros testes receberão IDs livres após nova conferência; os códigos C-RFxx/C-RNFxx/C-SAVE continuam sendo cenários de A02, não resultados ou testes globais.

## 2. Ciclo e tipos de evidência

**Requisito → prompt integral → saída original preservada → revisão humana → correção quando necessária → teste → integração → análise.** A volta a etapas anteriores deve manter os vínculos, sem apagar a primeira saída ou o resultado desfavorável.

| Etapa | O que permite concluir | Evidência mínima e limite |
|---|---|---|
| Compilação | A solução daquela versão compilou nas condições registradas. | Comando/configuração, versões, saída e responsável. Não prova jogabilidade, ausência de defeitos ou FPS estável. |
| Validação funcional | O cenário executado produziu ou não o comportamento esperado. | Condição inicial, passos, esperado/observado e evidência. Não generalizar um caso positivo para condições negativas não executadas. |
| Revisão arquitetural | Um revisor analisou responsabilidades, estado, referências, sinais, acoplamento e uso da engine. | Achados/decisão reais na matriz A08/ficha; nome, versão e escopo. Pode terminar sem correção; não prova desempenho por inspeção. |
| Medição de estabilidade/desempenho | Houve observação limitada, com métrica e contexto definidos. | Série bruta, configuração, versão, duração e repetições. Sem inferência para máquinas/modos não testados ou prova absoluta de ausência de vazamentos. |
| Aprovação documental | Pessoas revisaram e aceitaram regras/protocolo/modelos daquela versão. | T01 ou T03 com participantes e decisões. Não é execução das mecânicas ou medição da demo. |

### 2.1 Vínculo com os requisitos, sem repetir a matriz

- **RF01/RF02:** C-RF01/C-RF02, A02 §2.2 e regras §4; futuras A05/A10. Relacionar movimento/colisão e vida/dano/reinício à versão testada.
- **RF03/RF04:** C-RF03/C-RF04, A02 §2.2/4; futuras A06/A10. Incluir vivo/atordoado, comando, duplicação, ativa/representação e uso após troca/morte/carga.
- **RF05/RF06:** C-RF05/C-RF06 e C-SAVE, A02 §2.2/3/6; futuras A07/A10. Cobrir chave ausente, errada/inativa e correta; retorno, manutenção na sessão e reinício do mundo na morte/carga.
- **RNF01:** C-RNF01, rastreabilidade deste protocolo e revisão A08; **RNF02:** C-RNF02 e inventário/fontes humanas A04; **RNF03:** C-RNF03, aviso no pacote A09/A10.
- **RNF04:** C-RNF04/DEC10, protocolo das seções 4–6, execução principalmente A10. **RNF05/RNF06:** C-RNF05/C-RNF06 e reprodução do projeto/pacote final A09/A10. A01 fornece precedente de ambiente/exportação, não aprovação antecipada da demo.

Em cada conclusão, distinguir **redação original**, **critério de execução da A02** e **alteração humana reconhecida**. Para C-SAVE, o esperado é o contrato revisado; o resultado deve dizer “conforme o recorte aprovado, com divergência de persistência da fonte”, quando aplicável. Mudança legítima de regra não deve ser registrada automaticamente como defeito do código anterior.

### 2.2 Situação do teste e situação do requisito

| Situação da execução de teste | Regra de registro |
|---|---|
| Não executado | Há roteiro, mas a execução ainda não ocorreu. Observado fica sem preenchimento; registrar versão prevista ou “a definir”. |
| Bloqueado | A execução foi impedida por dependência identificada: funcionalidade, build, acesso, ferramenta ou dado ausente. Registrar dependência; não inventar comportamento observado. |
| Aprovado | Execução válida cumpriu todos os resultados esperados do cenário, com evidência suficiente. |
| Reprovado | Execução válida observou divergência reproduzível ou suficientemente documentada em relação ao esperado. Vincular achado, sem presumir causa/autoria. |
| Inconclusivo / inválido | Dados insuficientes ou condições quebradas: PID errado, foco perdido, desvio de percurso, coleta ausente. Manter registro e motivo; repetir quando possível, sem tratar como aprovação ou falha funcional comprovada. |

“Executado” é uma informação de ocorrência, não sinônimo de aprovado. Manter a data e a tentativa de cada execução; reteste não substitui a tentativa anterior. Na Tabela 3, usar a situação específica e a ficha para detalhar a tentativa.

| Situação do requisito naquela versão | Regra de consolidação |
|---|---|
| Atendido | Todos os critérios aplicáveis definidos para a versão e recorte foram cobertos por evidência válida, incluindo os casos negativos necessários. Informar limites/diferenças da fonte. |
| Atendimento parcial | Parte dos critérios está comprovada e outra parte tem falha, pendência ou cobertura ausente; listar exatamente ambas. |
| Falha | Uma condição essencial foi validamente observada em desacordo com o esperado, impedindo o atendimento. Listar critérios não testados separadamente. |
| Bloqueado | Ainda não há evidência suficiente porque uma dependência impede as verificações necessárias; identificar qual. |
| Sem execução / sem evidência | Nenhuma execução/auditoria aplicável foi realizada ou apresentada para essa versão. Ausência de teste não significa código defeituoso. |

Se houver evidência de atendimento e falha, usar atendimento parcial ou falha essencial, conforme o critério afetado, com justificativa; nunca “atendido” só porque algum teste passou. Uma condição não aplicável exige justificativa humana, sem exclusão silenciosa do denominador dos 12 requisitos. Aprovação de documento ou disponibilidade de compilação não altera automaticamente a situação dos RF da demo.

**Obrigatório em qualquer resultado:** ID/cenário/requisito e critério versionado; commit e estado de alterações locais; identificação/hash da build quando houver; executor/revisor efetivo; data; condições iniciais e equipamento; passos; esperado e observado separados; situação; evidência e limitações. Sem isso, a conclusão é inconclusiva ou fica pendente, conforme o que faltar. Dados não medidos são identificados como tais, nunca preenchidos com zero.

## 3. Gerações, curadoria, defeitos e versões

### 3.1 Estrutura existente e registro mínimo

Usar o [diário principal](Diario_Experimento_Cyra.md), o índice [Prompts utilizados](Prompts_Utilizados.md), `docs/prompts/`, `docs/saidas_originais/`, `docs/evidencias/` e os commits. O [Diário_Experimento_IA](Diario_Experimento_IA.md) continua template/referência histórica, não outro diário concorrente; não duplicar ali toda a coleta.

Por geração ou alteração assistida, registrar na ficha D correspondente:

1. Atividade/requisitos/cenários e limites; prompt integral, incluindo esclarecimentos que mudaram o contrato, com próximo ID P livre.
2. Ferramenta, modelo e versão quando conhecidos. Caso contrário, “modelo não aferido”; não reconstruir retrospectivamente.
3. Arquivos afetados e natureza: código, cena, configuração ou **documental**. Uma tarefa documental não é geração de código.
4. Saída original identificável antes de futura edição humana: arquivo/ZIP e manifesto SHA-256, ou commit explícito; indicar o marco preservado e o que ele contém.
5. Revisor humano, data, escopo examinado, critérios e achados reais; pode haver revisão sem correção. Não exigir alteração artificial para demonstrar curadoria.
6. Decisão e intervenção: quem decidiu, quem efetivamente editou, trecho/arquivo ou regra afetada, razão; novo prompt se a correção foi solicitada à IA.
7. Execuções e retestes ligados por ID/tentativa, versões, resultados/evidências; dependências e pendências separadas.
8. Versão revisada/integrada, arquivos/commit, situação e limites, além de esforço real conforme seção 7.

**Ajustes da própria IA** entre tentativas internas, antes de entregar a saída, são geração/correção assistida, não revisão humana. Uma pessoa pode identificar um problema e pedir à IA para editar: registrar a **decisão humana** e a **edição pela IA**, sem declarar que a pessoa escreveu o código. Resultados de verificações automáticas continuam automáticos, mesmo quando iniciados por uma pessoa.

Se o usuário já revisou uma saída, preservar essa sequência. Não regravar prompts, ZIPs ou hashes antigos para fazê-los coincidir com a versão humana. Um hash de fonte consultada identifica aquela versão histórica; não se espera que a fonte de trabalho revisada continue com o mesmo hash do original.

### 3.2 Categorias simples para os achados

| Categoria | Exemplo de classificação, sem alegar ocorrência |
|---|---|
| Compilação | Erro de sintaxe/tipo ou geração de bindings. Distinguir pacote ausente de erro de código. |
| Referência/sinal | Nó inexistente, referência indevida, conexão duplicada ou sinal não recebido. |
| Colisão | Máscara/forma/alinhamento ou transposição física incorreta. |
| Estado | Aquisição/ativa, uso por ciclo, morte, atordoamento ou transição incoerente. |
| Persistência | JSON inválido, campos errados, vida/checkpoint incoerentes ou falha de gravação mal tratada. Não chamar reset do mundo de defeito quando for o esperado aprovado. |
| Interface/representação | Vida/forma exibida divergente do estado, controles/aviso ilegíveis ou incompletos. |
| Ambiente | SDK/templates/pacotes/driver/permissão ou ferramenta de coleta ausente. |

Categoria e causa são campos distintos. Quando a causa não estiver demonstrada, usar “não determinada”. Aprendizagem da engine é esforço; não é por si só defeito. A origem pode ser geração, integração, configuração, regra alterada ou desconhecida; não atribuir automaticamente toda falha à IA. Uma deficiência de arquitetura pode ser anotada como tipo de achado de revisão, ligada à categoria pertinente, sem inventar falha funcional.

### 3.3 Achado, intervenção e reteste

Manter três registros ligados: **defeito/achado identificado** (evidência, gravidade/impacto e versão), **intervenção realizada** (autor real, ação/decisão e nova versão) e **resultado do reteste** (cenário/tentativa, esperado/observado e evidência). Corrigir não comprova que o problema foi resolvido. “Não exige correção, comportamento conforme regra” é decisão válida fundamentada; não contar mudança de escopo como defeito corrigido.

Para o texto acadêmico, relacionar requisito → P → D/arquivo original/hash → achado/decisão → diff ou descrição precisa da intervenção → teste/reteste → commit integrado. Citar trechos representativos e caminhos/versões; não reproduzir todo o código. Se a primeira saída não executar, registrar a falha e os limites observáveis; não inventar FPS dessa saída.

## 4. Equipamento e condições de referência — proposta vinculada à DEC10

### 4.1 Equipamento observado, ainda não escolhido pela equipe

Consulta local somente de leitura realizada em **22/10/2026**, por Codex, via informações de hardware/sistema e versões. Não foi execução ou medição do jogo. Não foram coletados números de série, usuário do Windows ou resultados de desempenho.

| Campo | Observado nesta máquina |
|---|---|
| CPU | Intel Core i5-12400F (12ª geração), 6 núcleos / 12 processadores lógicos. |
| GPU / driver | NVIDIA GeForce GTX 750; driver reportado pelo Windows `32.0.15.6094`. VRAM não levantada. |
| RAM física reportada | `17.004.335.104` bytes, aproximadamente 15,84 GiB; não é memória livre nem consumo do jogo. |
| SO / arquitetura | Windows 11 Pro 25H2, `10.0.26200`, build `26200.9711`, x64. |
| Modo de vídeo observado | 1920 × 1080, 60 Hz reportados pelo adaptador; não decide a janela/resolução do ensaio. |
| Godot / SDK | `4.7.2.stable.mono.official.ed1daf0bf`; `dotnet --version`: `8.0.422`. |
| Projeto atual, leitura do arquivo | Viewport 960 × 540, `canvas_items`, `gl_compatibility`, Nearest. VSync e limite de quadros não estão explícitos em `project.godot`; não inferir o modo efetivo da build final por ausência do campo. |
| Ferramentas locais observadas | `taskmgr.exe`, `perfmon.exe` e PowerShell presentes. Opções `--print-fps`, `--log-file` e `--max-fps` constam na ajuda local da engine. Coleta na build final ainda não verificada. |

**Proposta MR01:** adotar essa máquina como referência, somente se a equipe confirmar sua disponibilidade. Se outra for escolhida, preencher todos os campos novamente e identificar MR02; não misturar resultados como se fossem da mesma máquina. Não extrapolar estes dados para o computador de Lucas ou para o equipamento da banca.

### 4.2 Perfil proposto de execução

| Item | Proposta para aprovação humana |
|---|---|
| Pacote principal | Windows Desktop x86_64, **ExportRelease**, fora do editor; guardar executável, PCK/bibliotecas e identidade do pacote completo. Editor fechado. |
| Identidade | Commit completo, alterações locais (ou árvore limpa), data/ID da build e SHA-256 do ZIP do pacote fechado. Um hash só do EXE não identifica PCK/assemblies modificados. |
| Tela/janela | Viewport e área de cliente 960 × 540, janela comum, sem redimensionar, no monitor observado 1920 × 1080/60 Hz. Registrar escala de exibição efetiva e tamanho real da janela. |
| Renderizador | Compatibility/OpenGL da build final; confirmar driver/método efetivo no log. Sem trocar para outro renderizador entre séries. |
| Sincronização | Proposta: VSync ativado, limite 60 FPS (`--max-fps 60`), registrar qualquer override do driver. Confirmar no piloto; não alterar o projeto nesta tarefa. Este teto é condição operacional proposta, não meta da fonte. |
| Ambiente | Mesma sessão/configuração de energia; fechar aplicações dispensáveis; registrar modo de energia, gravação de tela/overlays e processos de fundo relevantes. Não desativar serviços nem alterar segurança para o ensaio. |
| Foco | Manter jogo em primeiro plano, sem minimizar ou pausar por troca de janela. Observador/coletor deve evitar tirar foco; registrar a ocorrência se acontecer. |
| Instrumentação | Mesmas opções de log/FPS e coleta de contadores em todas as repetições. Captura de vídeo contínua só se aprovada e mantida igual, porque pode afetar a execução. |

Antes das séries, fazer um **piloto de viabilidade futuro**, depois que a demo existir: conferir saída de FPS, seleção do PID real do jogo (não wrapper/editor), contadores, alinhamento dos relógios, tamanho da janela e tempos do percurso. O piloto não é uma medição realizada nesta A03. Se o percurso não couber nas janelas propostas, a equipe ajusta e versiona o protocolo **antes** da coleta formal, sem acelerar a engine ou mudar a rota para esconder um resultado.

## 5. Cenários de execução futura — não executados

Os códigos abaixo são **rótulos de séries do protocolo**, não novos testes globais. Usam o percurso A02 e não adicionam inimigos, botão de reset ou ferramenta de telemetria. O setup de save usa o arquivo único da demo; cópias de referência para evidência são artefatos de teste externos, não slots do produto. Usar uma conta Windows de ensaio ou guardar/restaurar o save pessoal identificado antes/depois das séries. Copiar o pacote para outra pasta não isola, por si só, `user://`: confirmar o caminho efetivo na máquina antes de preparar o estado inicial, sem alterar configurações nesta A03.

### 5.1 PROG — progressão inicial e FPS do percurso completo

**Condição inicial por repetição:** processo novo, sem save, S1/seguro_01, vida máxima do jogo, sem aquisições, ativa `null`, todos inimigos vivos e obstáculos fechados. Após a inicialização, não editar o JSON, reler save nem reiniciar o processo durante a série. Respeitar os eventos normais de gravação da A02.

**Proposta:** 60 s de aquecimento no trecho básico de S1, sem derrotar/absorver o inimigo nem transpor O1; depois janela de **5 min**, três repetições independentes, com processo/save inicial restaurados entre elas. Três é sugestão prática do guia, não obrigação da fonte.

Rota e pontos de anotação fixos:

1. P0 — seguro_01, início da janela medida; mover/pular, combater A até atordoar, absorver por comando, conferir A ativa e pulo duplo.
2. P1 — superar O1 com A, entrar em S2/seguro_02; combater B até atordoar, absorver, conferir B ativa e investida.
3. P2 — superar O2 com B, chegar a S3/seguro_03 e fim_03. Registrar vida, adquiridas, ativa e mundo da sessão.
4. P3 — retornar S3→S2→S1 pelas conexões abertas; alternar A/B e usar ambas sem renovar usos indevidamente; terminar em seguro_01 com A ativa.
5. P4 — repouso final de 60 s em seguro_01, mesma posição/forma e nenhuma ação. Separar este trecho ocioso das estatísticas do trecho ativo.

Pacing proposto para o piloto: P0–P1 no primeiro minuto, P1–P2 até 2 min 30 s, retorno até 4 min, repouso 4–5 min. Não é teste de habilidade do operador: tempos reais/erros de execução são anotados; se não for repetível, ajustar o protocolo antecipadamente. Não incluir longas esperas como parte ativa para elevar a média de FPS. Esta série exercita a primeira aquisição, combate, absorção, bloqueios, habilidades e transições; **não é série estacionária suficiente para concluir tendência de memória**, pois carrega recursos e muda o progresso pela primeira vez.

### 5.2 CONT — memória e estabilidade em processo contínuo

**Condição inicial:** processo novo e save válido de teste em S1/seguro_01, vida positiva máxima conforme catálogo, A/B adquiridas e A ativa. O save não contém inimigos/obstáculos: ambos começam reiniciados na carga. A origem desse save e seu hash devem ser registrados; produzir esse estado pela própria progressão e conservar uma cópia de referência é suficiente, sem implementar gerador de fixtures.

**Aquecimento proposto de 2 min:** executar uma volta completa S1→S2→S3→S2→S1, combater e absorver os dois inimigos já conhecidos sem duplicar aquisições, superar O1/O2 e retornar a seguro_01 com A ativa. Registrar vida positiva ao final. Se a rota ainda não for possível em 2 min, ajustar no piloto. O aquecimento carrega os trechos/ações antes da comparação de memória.

**Coleta proposta:** cinco ciclos de **2 min**, total 10 min após o aquecimento, sem matar o jogador, fechar, recarregar o save ou reiniciar o mundo. Repetir a série completa três vezes, com processo novo e mesmo save de referência entre séries.

- Cada ciclo usa a mesma volta S1→S2→S3→S2→S1, ações de A/B nos mesmos trechos e retorno a seguro_01, A ativa. Não redimensionar a janela nem fazer captura/inspeção intrusiva só em uma repetição.
- Os inimigos absorvidos e os obstáculos superados **continuam nesse estado** ao longo dos ciclos, conforme A02. Não inventar novos combates/absorções a cada volta; essas ações pertencem ao aquecimento e à PROG. Esta diferença é intencional e deve aparecer na análise.
- Reservar os últimos 10 s de cada ciclo para repouso na mesma posição/forma. Registrar M0 nos 10 s finais do aquecimento e M1–M5 nesses repousos. Usar mediana do mesmo contador nas janelas, além da série bruta contínua e máximo observado.
- Não usar morte como reset de conveniência: ela reinicia o mundo e muda a condição. Morte acidental, foco perdido ou desvio torna a tentativa afetada inválida para comparação contínua; manter os dados e o motivo. Um defeito real que cause a morte/travamento indevido é também achado funcional, com evidência própria.

Esse ensaio observa principalmente retenção de estado, transições/carga de seções e crescimento sustentado do processo depois do aquecimento. Não cobre todos os padrões de combate, reabertura ou sessões longas. Não forçar coleta de lixo para melhorar o resultado; oscilações do runtime/caches são parte da observação.

### 5.3 SAVE — persistência/reabertura e morte, separados de CONT

Executar C-SAVE/C-RF05/C-RF06 por referência à A02; prever ao menos:

- Ausência, validade, JSON/IDs/versão inválidos e falha de escrita, usando cópia controlada do arquivo e ambiente de teste. O mecanismo seguro de induzir erro de acesso deve ser definido na atividade de teste; se faltar, registrar bloqueio, sem alterar permissões da máquina indiscriminadamente.
- Salvar em S2/S3, vida positiva e habilidades conhecidas; fechar/reabrir e conferir **vida salva, checkpoint e ativa**, com inimigos/obstáculos reiniciados. Comparar os campos efetivos do arquivo, sem exigir os campos removidos pela equipe.
- Durante a mesma sessão, sair/voltar e verificar inimigo vivo/atordoado/absorvido e bloqueio aberto mantidos em memória. Atordoamento não expira por tempo.
- Morte antes/depois da absorção: mundo reinicia, vida máxima no ponto seguro atual, aquisições e ativa mantidas; retorno pelos bloqueios reiniciados em ambos os sentidos. A morte deve decorrer de mecânica normal disponível ou condição de teste autorizada na implementação correspondente. Se ainda não houver forma viável, marcar bloqueado; não criar nova ferramenta nesta A03.
- Arquivo inválido inicia estado base com aviso e próxima gravação válida substitui o único arquivo; falha de escrita preserva a sessão e o último arquivo válido. Confirmar a política aprovada, sem presumir recuperação de dados corrompidos.

Reabertura inicia outro processo; morte reinicia o mundo. **Não concatenar essas amostras** às séries CONT para fingir liberação/estabilização de memória no mesmo processo. Cada tentativa tem ID, versão, condição, horário e evidência próprios. No encerramento, restaurar a cópia pessoal se aplicável; não registrar isso como parte da mecânica de slots.

### 5.4 Custo e preparação

Proposta de coleta principal: PROG = 3 × (1 min aquecimento + 5 min), CONT = 3 × (2 min aquecimento + 10 min), **54 min de execução planejada**, sem contar setup, SAVE, diagnóstico, coleta/revisão e repetição de tentativas inválidas. Reservar aproximadamente um bloco de 90 min para piloto e essas séries, ajustando conforme viabilidade; não é esforço já gasto nem alteração do cronograma. Testes funcionais negativos e análise têm tempo próprio. Se houver somente duas repetições válidas, relatar duas, sem inventar a terceira nem ocultar a razão.

## 6. Métricas, coleta e critérios operacionais propostos

### 6.1 Coleta viável e dependências

| Métrica | Método proposto | Limites e alternativa |
|---|---|---|
| FPS do pacote | Executável/console wrapper da build com `--print-fps --max-fps 60`; preservar stdout e log da engine por repetição, inclusive erros. Associar amostras à linha do tempo anotada. | A opção consta na engine instalada; validar a saída/cadência no piloto da build. FPS por intervalo não é trace por quadro. Se a captura de stdout não funcionar, usar os Monitors no editor em série separada; FPS release fica indisponível até resolver, sem transpor o número do editor. |
| Memória do processo | Performance Monitor do Windows: contadores **Process/Private Bytes**, **Working Set** e **ID Process**, processo correto, intervalo proposto 1 s; salvar log bruto e exportação legível quando disponível. | Selecionar por PID, conferir nome da instância/horário; não coletar o wrapper ou o editor como se fosse o jogo. Nomes dos contadores podem ser localizados. Configuração e acesso serão testados no piloto; nada é configurado agora. |
| Memória com coleta manual | Alternativa: Gerenciador de Tarefas/Monitor de Recursos, processo/PID corretos, coluna com nome exato, leitura em M0–M5. | Identificar se é working set, working set privado ou tamanho de confirmação. Não renomear uma coluna como Private Bytes sem equivalência comprovada. Amostras pontuais não fornecem série a 1 s nem pico global; conclusões ficam limitadas. |
| Tempo de quadro/engine | Série **DIAG**, separada: Godot Debugger/Monitors e Profiler, se suportados na versão/projeto, para tempo de processamento/física por quadro, com unidade original e conversão s→ms. | Não confundir CPU da engine com latência entre apresentações/GPU. A disponibilidade/detalhamento do profiler para C# deve ser conferida, sem assumir perfil por método. Falta de trace por quadro impede p95/p99 de frametime; não inventar percentis. |
| Memória da engine | Monitors em DIAG, com nome exato e modo debug, para diagnóstico adicional. | `MEMORY_STATIC` não é a memória total do processo e não está disponível em release; leitura indisponível é “não disponível”, não zero. Não substituir nem somar a Private Bytes/working set. |
| Travamentos/erros/perda de estado | Observador com linha do tempo, saída/log, código de saída quando disponível, estado esperado/observado nos marcos e referência a evidência funcional. | Não atribuir a causa sem investigar. Sem observador/log adequado, não declarar ausência de erros/perda só porque há FPS. |

A documentação da [linha de comando Godot](https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html) confirma as opções de execução, inclusive FPS em stdout; a ajuda local confirma sua presença em 4.7.2. A captura será validada antes de coletar a demo final. Não usar `--headless` ou `--fixed-fps` para medir desempenho gráfico: a primeira não representa a renderização do pacote, a segunda altera sincronização real. Um log interno de erros não garante capturar stdout; conservar ambos ou verificar expressamente a captura.

**Performance Monitor futuro, sem automação nova:** abrir a ferramenta já presente, configurar manualmente um conjunto de contadores do processo e intervalo de 1 s, selecionar saída em evidências da execução, iniciar/parar com horários anotados e conferir o PID. Se a interface exigir permissões indisponíveis, usar coleta manual e declarar a limitação. A [documentação Microsoft](https://learn.microsoft.com/en-us/troubleshoot/windows-server/support-tools/troubleshoot-issues-performance-monitor) descreve coleta de contadores; seus exemplos de servidor não são comandos a executar nesta entrega.

**Semântica da memória:** Private Bytes representa memória privada comprometida/alocada que não é compartilhável; inclui memória não residente. Working set descreve páginas presentes na RAM, inclusive compartilhadas. Nenhuma das duas equivale a VRAM ou somente ao heap C#. Registrar bytes e derivar MiB por divisão por `1.048.576`; não misturar MB decimal. Essas distinções seguem [PrivateMemorySize64/Private Bytes](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.privatememorysize64?view=net-10.0) e [WorkingSet64](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.workingset64?view=netframework-4.7.2), sem necessidade de escrever um coletor C#.

### 6.2 Série DIAG separada do pacote

Se necessária para explicar uma falha, reproduzir cenário no editor, em janela própria de jogo com a mesma resolução, e identificar **DIAG/editor/debug**, versão, monitores/profiler ativos, PID do jogo e duração. Registrar CPU de frame/física, memória/objetos da engine e logs disponíveis. Não somar o consumo do editor ao do processo do jogo nem mesclar medianas ou amostras com PROG/CONT release. A instrumentação pode alterar o comportamento e custo; ela apoia diagnóstico, não certifica automaticamente o pacote final. Diferenças entre séries são observações com condições distintas, sem atribuir causalidade automática.

Monitores de FPS/memória e o profiler são ferramentas nativas do [Debugger](https://docs.godotengine.org/en/stable/tutorials/scripting/debug/debugger_panel.html). A [referência Performance](https://docs.godotengine.org/en/stable/classes/class_performance.html) distingue FPS, tempo de processamento e monitores de memória, com restrições de disponibilidade em release. Para intervalos **reais entre quadros apresentados** e seus percentis, falta um trace apropriado: dependência de ferramenta externa validada pela equipe ou instrumentação futura autorizada. Alternativa simples é relatar FPS agregado e tempo de CPU da engine separadamente, com limitação explícita, sem transformar `1000/FPS` em medição individual de frametime.

### 6.3 Tratamento das amostras

Conservar dados brutos e mapa dos períodos: inicialização, aquecimento, ativo, repouso, transição e ocorrência. Sincronizar horários do log/contadores e anotar o T0; se stdout não trouxer horário, registrar a cadência real e referência temporal sem fingir precisão por quadro. FPS: mediana, mínimo e proporção de amostras válidas acima do limiar, por trecho e repetição; informar quantidade/cadência/cobertura, sem p95 de quadros a partir de médias por segundo. Memória: valores M0–M5 e máximos da série bruta, sempre com o mesmo contador/unidade e ponto comparável.

Se uma amostra estiver ausente, marcar ausente; não interpolar zeros, não repetir último valor como observação nova. Proposta de validade para FPS: pelo menos 95% das amostras esperadas na cadência confirmada, com T0/fim e trecho identificados; lacunas concentradas em transições/falha exigem investigação, mesmo com cobertura global alta. Séries insuficientes não passam por falta de dados. Não excluir trechos lentos válidos; separar aquecimento conforme regra fixada antes, não depois de ver resultados.

### 6.4 Aceitação operacional — proposta IA, não requisito original

| Dimensão | Critério proposto para a máquina/perfil aprovados | Encaminhamento |
|---|---|---|
| Reprodutibilidade | Mesmo pacote identificado, máquina/perfil, estado inicial e rota; coleta válida por repetição. | Condição quebrada: tentativa inválida/inconclusiva, com causa; não substituir por amostras de outra build sem identificar. |
| Funcional/estado | Zero travamento/encerramento inesperado, zero erro de execução não tratado e zero divergência de vida/habilidades/checkpoint/estado de sessão em execuções válidas. | Abrir achado e retestar versão corrigida. Morte prevista no teste funcional não é crash. |
| FPS | No trecho ativo PROG e na CONT: mediana por repetição ≥55 FPS e ≥95% das amostras válidas ≥50 FPS, com teto operacional 60. | Os números são proposta de tolerância, não meta da fonte. Ocioso não substitui ativo; avaliar cada repetição, sem mascarar uma falha pela média geral. |
| Interrupção perceptível | Nenhuma falta de resposta contínua observada por mais de 1 s durante controle normal, fora das esperas planejadas; anotar transições separadamente. | Observação manual é aproximada e requer evidência/horário. Sem trace, não afirmar que não houve hitch menor que 1 s. |
| Memória pós-aquecimento | Investigar se M5−M0 em Private Bytes exceder `máximo(20 MiB, 10% de M0)`, **ou** se M2→M3→M4→M5 crescer em todos os passos sem estabilização aparente. | É gatilho operacional de investigação, não diagnóstico de vazamento. GC/caches e mudanças de recursos podem explicar crescimento. Registrar e repetir/estender ensaio dirigido, com versão/tempo próprios. |
| Conclusão de estabilidade | Só declarar “sem crescimento sustentado acima do critério neste cenário/duração” com séries válidas e análise dos pontos/curva; um pico isolado não prova vazamento. | Não declarar ausência absoluta de vazamentos. Se houver gatilho sem explicação/reteste suficiente, RNF04 fica inconclusivo ou parcial, nunca automaticamente aprovado. |

Os limites e a referência a 60 FPS serão aprovados ou alterados em T03, antes de A10. Não reduzir limites retrospectivamente só para aprovar uma série. Se alterados por motivo justificável, guardar versão anterior, motivo e reavaliar com regra identificada. A métrica indisponível fica sem avaliação; não confundir ausência de evidência com reprovação funcional observada. O limite de memória exige Private Bytes; a alternativa de coluna manual diferente não valida automaticamente o mesmo critério.

## 7. Esforço e modelos mínimos para registros futuros

### 7.1 Contabilização por etapa

Usar a ficha D existente para detalhar etapas, sem reformatar retroativamente toda a Tabela 1. Registrar início/fim ou duração medida, pessoa efetiva, atividade, tipo e fonte da medida:

- Preparação/ambiente/aprendizagem: instalação, leitura da engine e exploração para aprender; separar quando for possível, sem atribuir automaticamente ao código.
- Geração assistida: preparar/enviar prompt, acompanhar e verificar saída da IA. Identificar tempo decorrido e envolvimento humano; espera sem atuação não é automaticamente esforço humano ativo.
- Revisão humana: ler/analisar código, cena ou documento e decidir, mesmo sem correção.
- Correção: editar ou orientar correção por IA; distinguir executor da edição e decisor. Não contar o mesmo intervalo em revisão e correção duas vezes.
- Teste/coleta: executar/repetir cenários, registrar e conferir dados; integração: resolver referências/merge/empacotamento e verificar a versão integrada.

Tempo decorrido mede um intervalo de calendário; esforço por pessoa mede atuação efetiva; reunião conjunta é um registro de participação/duração coletiva. **Não multiplicar automaticamente uma reunião por participantes** nem duplicá-la como correção individual de todos. Para pessoa-minuto, só somar participações individuais confirmadas, identificando a unidade e intervalos, sem confundir com duração do projeto. Atividades paralelas podem somar esforço e compartilhar tempo decorrido; explicitar isso. D02 conserva os **33 min conjuntos relatados** e tempos posteriores não medidos; nenhum é recalculado aqui.

Se não houve medição confiável: **“não medido”**. Estimativa posterior só pode existir como estimativa identificada com origem, fora dos totais cronometrados. A duração da resposta da IA não é tempo total de desenvolvimento. Sem referência manual independente, não calcular economia, ganho percentual de produtividade ou superioridade frente a desenvolvimento manual.

### 7.2 Modelos enxutos — ainda sem observações

Copiar os modelos para fichas/evidências da execução quando ocorrer. Eles não constituem linhas executadas na Tabela 3. Campos observados abaixo ficam intencionalmente vazios; valores de planejamento só entram em “previsto”.

**Execução funcional ou documental**

| Campo | Preenchimento futuro |
|---|---|
| ID global reservado / cenário A02 / requisito / critério versionado | |
| Natureza: funcional, documental, arquitetura ou ambiente | |
| Versão/commit; alterações locais; build/hash quando aplicável | |
| Executor/revisor efetivo; data e condições de equipamento | |
| Estado inicial do save/sessão; dependências | |
| Passos e resultado esperado | |
| Resultado observado; evidência; limitações | |
| Situação do teste / achado / tentativa de reteste | |
| Situação do requisito, cobertura e critério ainda pendente | |

**Série de desempenho/estabilidade**

| Campo | Preenchimento futuro |
|---|---|
| ID da execução; PROG/CONT/DIAG; repetição e responsável | |
| Protocolo aprovado/versão; commit/build/hash completo do pacote | |
| Máquina; SO/driver; resolução/janela; renderizador; VSync/limite; foco/energia | |
| Tipo: pacote release ou editor/debug; instrumentação e PID | |
| Save inicial/hash; estado do mapa; aquecimento e rota previstos | |
| Horários reais; duração real; pontos P/M; desvios e lacunas | |
| Método/contador/unidade/cadência; caminhos dos dados brutos | |
| FPS por trecho/repetição, tamanho/cobertura da amostra | |
| M0–M5, máximos e tendência por contador; tempo de CPU ou trace disponível | |
| Erros/travamentos/perda de estado, com evidência e horário | |
| Resultado observado; limites usados; situação; necessidade de investigação | |

**Defeito/achado e reteste**

| Campo | Preenchimento futuro |
|---|---|
| ID do achado, categoria, impacto, origem/causa demonstrada ou desconhecida | |
| Requisito/cenário/teste/tentativa e versão onde foi identificado | |
| Esperado, observado, reprodução e evidência | |
| Quem identificou; data; decisão e intervenção realizada | |
| Executor real da edição; prompt se IA; tempo medido por etapa | |
| Versão corrigida/integrada; teste/tentativa do reteste e evidência | |
| Resultado do reteste; aberto/encerrado e justificativa | |

### 7.3 Consolidação sem inflar os resultados

- **Requisitos:** apresentar distribuição de estados para os **12 RF/RNF**, com versão/recorte; “atendidos/12”, “parciais/12”, “falhas/12”, “bloqueados/12” e “sem execução/12”. Não somar estados sobrepostos. Tratar a obrigação de persistência textual adicional e sua alteração humana separadamente, sem escondê-la no percentual nem criar requisito novo da fonte.
- **Testes:** separar documentais (T01/T03), ambiente (T00) e funcionais/medições da demo. Taxa de aprovação = aprovados / (aprovados + reprovados) **das tentativas válidas com veredicto**, informando o denominador. Mostrar também tentativas inconclusivas/inválidas, bloqueadas e não executadas. Não escrever apenas “aprovados sobre executados” se o universo de executados incluir inconclusivos sem explicitar a exclusão.
- Para transparência, mostrar ainda aprovados / total de tentativas iniciadas (incluindo inválidas/inconclusivas) e cobertura de cenários planejados, com denominador e natureza. Retestes contam como tentativas, não cenários novos; no resumo por cenário/versão, usar a última execução válida daquela versão e conservar o histórico.
- **Defeitos/intervenções:** contar achados únicos por categoria/impacto, abertos/encerrados com reteste e causas conhecidas/desconhecidas. Uma falha repetida pode ter várias tentativas, sem virar vários defeitos automaticamente. Separar mudanças de regra aprovadas, problemas de ambiente e ajustes internos da IA.
- **Esforço:** totais por etapa apenas dos intervalos medidos, com unidade/participantes, paralelismo e número de registros não medidos. Não preencher ausências como zero nem usar esses totais para comparação com uma implementação manual inexistente.
- **Medições:** resumir por perfil, versão, série, trecho e repetição válida, acompanhadas de dados brutos e cobertura. Se faltou funcionalidade, ferramenta ou coleta, informar dependência e situação; não preencher números esperados como observados.

## 8. Revisão humana da A03 — T03 preparado, não executado

Há uma [ficha preparada T03](evidencias/T03_A03_revisao.md), explicitamente pendente, para registrar a revisão real; ela não é evidência de aprovação. A Tabela 3 mantém observado e situação como `[Pendente execução humana]`. Não atribuir participantes por terem participado da reunião A02.

Roteiro para a equipe:

1. Conferir vínculos com os 12 RF/RNF/cenários A02, diferença entre fonte e alteração humana de persistência e distinção entre compilação, revisão, testes e medição.
2. Simular o preenchimento de um teste ainda sem funcionalidade (bloqueado), uma execução reprovada e um reteste aprovado, sem produzir resultados reais fictícios; conferir situações e denominadores.
3. Confirmar que PROG começa sem aquisições e que CONT aquece com combate/absorção, depois mantém o mundo no mesmo processo. Separar morte/reabertura para SAVE e editor para DIAG.
4. Fechar as escolhas metodológicas ainda pendentes da seção 9 e verificar que a coleta proposta é realizável nas condições escolhidas; registrar dependências do piloto futuro.
5. Conferir modelos, autoria das intervenções, esforço e preservação de originais; registrar achados/alterações e participantes reais, data, duração se medida e versão revisada. Somente então aprovar ou devolver o protocolo com pendências.

T03 nunca será reutilizado para um teste de mecânica diferente. Aprovação de T03 adota a versão metodológica identificada, não aprova antecipadamente PROG/CONT/SAVE, cenários A02 ou RNF04.

## 9. Escolhas metodológicas que ainda exigem confirmação humana

Todas as recomendações novas desta A03 são **propostas IA**; não há resposta da equipe registrada nesta entrega. As regras de jogo aprovadas em T01 não são perguntas pendentes.

| Escolha pendente | Proposta utilizável / pergunta objetiva |
|---|---|
| Máquina de referência | Adotar MR01 (i5-12400F/GTX 750/RAM reportada/Windows 11) ou indicar outra máquina e preencher ficha equivalente? |
| Condições de medição | Confirmar pacote release, janela 960 × 540, Compatibility, VSync ligado/limite 60 e energia/foco/instrumentação fixos? Confirmar valores efetivos no piloto. |
| Duração/repetições | Aceitar PROG 60 s + 5 min e CONT 2 min + 5 ciclos de 2 min, três repetições, com ajuste documentado de pacing no piloto? |
| Método de coleta | Usar stdout FPS + Performance Monitor a 1 s com PID e Private Bytes/Working Set; DIAG separado? Se não viável, escolher alternativa manual e registrar a perda de cobertura/métrica. |
| Limites de aceitação | Aceitar FPS mediano ≥55 e ≥95% das amostras ≥50, critérios de integridade/erro e gatilho de memória `máximo(20 MiB, 10%)`/crescimento de cauda, sem tratar como prova de ausência de vazamento? |
| Participantes efetivos | Quem revisará T03, operará a demo, observará/anotará e conferirá os dados em A10? Uma pessoa pode acumular funções, mas sem presumir atuação simultânea impossível ou atribuir nomes sem confirmação. |

Falha de dependência não confirmada no piloto futuro deve permanecer explícita, em vez de resultar em números fictícios. Não se pede nova aprovação das habilidades, morte ou campos de save já adotados.

## 10. Referências técnicas, preservação e limites

Referências oficiais consultadas em 22/10/2026 para conferir a viabilidade dos métodos: [CLI Godot](https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html), [Debugger Godot](https://docs.godotengine.org/en/stable/tutorials/scripting/debug/debugger_panel.html), [Performance Godot](https://docs.godotengine.org/en/stable/classes/class_performance.html), [coleta Windows Performance Monitor](https://learn.microsoft.com/en-us/troubleshoot/windows-server/support-tools/troubleshoot-issues-performance-monitor), [memória privada do processo](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.privatememorysize64?view=net-10.0) e [working set](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.workingset64?view=netframework-4.7.2). São referências de métricas existentes, não solicitação de trocar .NET 8.0.422. A documentação web `stable` pode evoluir; a ajuda local da engine 4.7.2 foi conferida e o piloto validará o pacote final.

Preservação D03: [arquivo original](saidas_originais/D03_A03.zip), [manifesto de integridade](saidas_originais/D03_SHA256.txt) e [fontes locais de referência](saidas_originais/D03_fontes_SHA256.txt). [P04 integral](prompts/P04_A03_prompt_integral.md), índice de prompts e ficha D03 ligam a solicitação à saída; P03/A02 e arquivos originais D01/D02 não são reescritos.

Os modelos e a ficha T03 têm campos observados sem preenchimento. A consulta de hardware não é resultado de benchmark. Nenhuma mecânica, instrumentação, coletor, script C#, cena, asset ou configuração do jogo foi criado/alterado; nenhum teste/medição da demo foi executado; nenhum commit/envio ao GitHub é feito nesta tarefa. Tempos da preparação não medidos. A proposta só se torna método adotado após revisão e registro humano de T03.
