extends Node
func _ready():
    var scene = load("res://Scenes/Test/TestSceneA01.tscn").instantiate()
    add_child(scene)
    await get_tree().create_timer(1.1).timeout
    scene.get_node("CanvasLayer/TestButton").pressed.emit()
    var actor = scene.get_node("TestActor")
    scene.get_node("TriggerZone").body_entered.emit(actor)
    Input.action_press("ui_accept")
    await get_tree().physics_frame
    Input.action_release("ui_accept")
    var marker = InputEventKey.new()
    marker.keycode = KEY_F9
    marker.pressed = true
    Input.parse_input_event(marker)
    push_warning("T04_expected_warning")
    push_error("T04_expected_error")
    await get_tree().create_timer(1.2).timeout
    get_tree().quit()
